# --*-- coding:utf-8 --*--
# @Time : 2026/4/21 12:38
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : sub.py
# @Software : PyCharm

import codecs
import json
import logging
import queue
import socket
import threading
import time
from typing import Any, Callable

import requests

from cjpy.base import get_default_client
from cjpy.utils import tscode


DEFAULT_CHUNK_SIZE = 1024
DEFAULT_CONNECT_TIMEOUT = 5
DEFAULT_READ_TIMEOUT = None
DEFAULT_ENCODING = "gbk"
DEFAULT_BOUNDARY = "__CJ_SUB_BOUNDARY__"
DEFAULT_QUEUE_MAXSIZE = 1000
LOGGER = logging.getLogger(__name__)
Event = dict[str, Any]


class SubscriptionError(RuntimeError):
    """订阅生命周期或配置错误。"""


class Subscription:
    """
    后台线程订阅对象。

    该对象封装了一个后台订阅线程，并通过内部队列向外暴露事件流。
    调用 :func:`subscribe` 会立即创建并启动一个 ``Subscription`` 实例。

    事件结构通常为一个字典，包含以下字段：

    - ``_event``: 事件类型，例如 ``"status"``、``"message"``、``"error"``
    - ``data``: 事件载荷
    - ``ts``: 事件生成时间字符串

    Notes:
        ``on_event`` 回调在订阅线程中同步执行，只适合做轻量、非阻塞处理。
        如果回调中包含耗时计算、网络请求、数据库写入或长时间等待，
        会直接阻塞订阅线程，导致消息处理延迟。重任务建议使用
        :meth:`get` 或 :meth:`drain` 在外部线程消费。
        内部事件队列默认长度为 1000；如果消费速度跟不上，队列满时会丢弃最旧事件，
        优先保留最新事件，以避免订阅线程因事件无限积压导致内存持续增长。
    """

    def __init__(
        self,
        ids: list[str],
        fields: list[str],
        type_: int = 1,
        client: Any = None,
        on_event: Callable[[Event], None] | None = None,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        connect_timeout: int | float = DEFAULT_CONNECT_TIMEOUT,
        read_timeout: int | float | None = DEFAULT_READ_TIMEOUT,
        encoding: str = DEFAULT_ENCODING,
        boundary: str = DEFAULT_BOUNDARY,
        queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
        logger: logging.Logger | None = None,
    ) -> None:
        self.client = client or get_default_client()
        self.ids = [tscode(code) for code in ids]
        self.fields = fields
        self.type_ = type_
        self.on_event = on_event
        self.chunk_size = chunk_size
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.encoding = encoding
        self.boundary = boundary
        self.queue_maxsize = queue_maxsize
        self.logger = logger or LOGGER

        self.queue = queue.Queue(maxsize=queue_maxsize)
        self._stop_event = threading.Event()
        self._thread = None
        self._response = None
        self._session = None

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> "Subscription":
        """
        启动后台订阅线程。

        Returns:
            Subscription: 当前订阅对象本身，便于链式使用。
        """
        if self.is_running:
            return self

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def stop(self, timeout: int | float = 2, force: bool = False) -> None:
        """
        停止订阅并关闭连接。

        Args:
            timeout: 等待订阅线程退出的秒数。
            force: 是否尝试强制关闭底层 socket。对于被阻塞的长连接可作为兜底手段。
        """
        self._put_event("stop_requested", {"force": force})
        self._stop_event.set()

        if force:
            self._force_close_socket()

        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=timeout)

    def _force_close_socket(self):
        for sock in self._iter_socket_candidates():
            shutdown = getattr(sock, "shutdown", None)
            if shutdown is not None:
                try:
                    shutdown(socket.SHUT_RDWR)
                except Exception:
                    pass

            close = getattr(sock, "close", None)
            if close is not None:
                try:
                    close()
                except Exception:
                    pass

            break

    def _iter_socket_candidates(self):
        response = self._response
        if response is None:
            return

        raw = getattr(response, "raw", None)
        if raw is None:
            return

        paths = [
            ("_fp", "fp", "raw", "_sock"),
            ("_fp", "fp", "raw"),
            ("_connection", "sock"),
        ]

        for path in paths:
            sock = raw
            try:
                for attr in path:
                    sock = getattr(sock, attr)
            except Exception:
                continue

            if sock is not None:
                yield sock

    def get(self, timeout: int | float | None = None) -> Event | None:
        """
        从订阅队列读取一条事件。

        如果已请求停止订阅，则不再阻塞，只返回队列中已有数据。

        Args:
            timeout: 阻塞等待秒数。为 ``None`` 时按 ``queue.Queue.get`` 默认行为处理。

        Returns:
            Event | None: 读取到的事件；超时或队列为空时返回 ``None``。
        """
        if self._stop_event.is_set():
            try:
                return self.queue.get_nowait()
            except queue.Empty:
                return None

        try:
            return self.queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def drain(self, max_items: int | None = None) -> list[Event]:
        """
        非阻塞取出当前队列中的多个事件。

        Args:
            max_items: 最多读取的事件数量。不传时读取直到队列为空。

        Returns:
            list[Event]: 按先入先出顺序返回的事件列表。
        """
        events = []
        count = 0

        while max_items is None or count < max_items:
            try:
                events.append(self.queue.get_nowait())
            except queue.Empty:
                break

            count += 1

        return events

    def get_latest(self) -> Event | None:
        """
        非阻塞获取队列中最新的一条事件。

        该方法会丢弃队列中更早的事件，只保留最后一条，适合只关心最新状态的场景。

        Returns:
            Event | None: 最新事件；队列为空时返回 ``None``。
        """
        latest = None

        while True:
            try:
                latest = self.queue.get_nowait()
            except queue.Empty:
                return latest

    def qsize(self) -> int:
        """
        返回当前队列中的待消费事件数量。

        Returns:
            int: 当前队列长度。
        """
        return self.queue.qsize()

    def wait_stopped(self, timeout: int | float | None = None) -> bool:
        """
        等待订阅线程结束。

        Args:
            timeout: 最长等待秒数。

        Returns:
            bool: 线程已经停止时返回 ``True``，超时未停时返回 ``False``。
        """
        if self._thread is None:
            return True

        if self._thread is threading.current_thread():
            return False

        self._thread.join(timeout=timeout)
        return not self.is_running

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.client.token}",
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "TS-EVENTNAME": "auto",
            "JSON-Encode": self.encoding,
            "TS-BOUNDARY": self.boundary,
        }

    def _payload(self):
        return {
            "Type": self.type_,
            "IDs": self.ids,
            "SUBs": self.fields,
        }

    def _put_event(self, event_type, data):
        event = {
            "_event": event_type,
            "data": data,
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        try:
            self.queue.put_nowait(event)
        except queue.Full:
            dropped_event = None
            try:
                dropped_event = self.queue.get_nowait()
            except queue.Empty:
                pass

            try:
                self.queue.put_nowait(event)
            except queue.Full:
                self.logger.warning(
                    "subscription queue is full; failed to enqueue event %s",
                    event_type,
                )
            else:
                dropped_type = dropped_event.get("_event") if isinstance(dropped_event, dict) else None
                self.logger.warning(
                    "subscription queue is full; dropped oldest event %s to enqueue %s",
                    dropped_type,
                    event_type,
                )

        if self.on_event is not None:
            try:
                self.on_event(event)
            except Exception:
                self.logger.exception("subscription callback failed for event %s", event_type)

    def _run(self):
        url = f"{self.client.base_url}/subscription"
        text_buffer = ""
        decoder = codecs.getincrementaldecoder(self.encoding)()
        stop_reason = "eof"

        try:
            self._put_event("status", {"state": "starting"})
            self._session = requests.Session()
            self._session.verify = self.client.verify
            self._session.headers.update(self._headers())

            self._put_event("status", {"state": "connecting"})
            self._response = self._session.post(
                url,
                json=self._payload(),
                stream=True,
                timeout=(self.connect_timeout, self.read_timeout),
            )
            self._response.raise_for_status()
            self._put_event(
                "subscribed",
                {
                    "status_code": self._response.status_code,
                    "ids": self.ids,
                    "fields": self.fields,
                    "type": self.type_,
                },
            )

            for chunk in self._response.iter_content(chunk_size=self.chunk_size):
                if self._stop_event.is_set():
                    stop_reason = "user"
                    break

                if not chunk:
                    continue

                text = decoder.decode(chunk)
                if not text:
                    continue

                text_buffer += text
                while self.boundary in text_buffer:
                    raw_msg, text_buffer = text_buffer.split(self.boundary, 1)
                    raw_msg = raw_msg.strip()

                    if not raw_msg:
                        continue

                    try:
                        self._put_event("message", json.loads(raw_msg))
                    except json.JSONDecodeError:
                        self._put_event("raw", raw_msg)

            tail = decoder.decode(b"", final=True)
            if tail:
                text_buffer += tail

            if text_buffer.strip():
                self._put_event("tail", text_buffer)

        except Exception as exc:
            if not self._stop_event.is_set():
                stop_reason = "error"
                self.logger.warning("subscription error: %s", exc, exc_info=True)
                self._put_event(
                    "error",
                    {
                        "type": exc.__class__.__name__,
                        "message": str(exc),
                        "repr": repr(exc),
                    },
                )
            else:
                stop_reason = "user"
        finally:
            self.logger.debug("closing subscription connection")
            if self._response is not None:
                try:
                    self._response.close()
                except Exception:
                    self.logger.debug("response.close() failed", exc_info=True)

            if self._session is not None:
                try:
                    self._session.close()
                except Exception:
                    self.logger.debug("session.close() failed", exc_info=True)

            self._response = None
            self._session = None
            self._put_event("stopped", {"reason": stop_reason})


def subscribe(
    ids: list[str],
    fields: list[str],
    type_: int = 1,
    client: Any = None,
    on_event: Callable[[Event], None] | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    connect_timeout: int | float = DEFAULT_CONNECT_TIMEOUT,
    read_timeout: int | float | None = DEFAULT_READ_TIMEOUT,
    encoding: str = DEFAULT_ENCODING,
    boundary: str = DEFAULT_BOUNDARY,
    queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
    logger: logging.Logger | None = None,
) -> Subscription:
    """
    启动后台订阅并立即返回 ``Subscription`` 对象。

    Args:
        ids: 订阅标的列表，例如["SZ000001", "SH000001"]。
        fields: 订阅字段列表，例如["StockName", "date_s", "price"]。
        type_: 订阅类型，默认1。
        client: 可选CjClient实例；不传则使用默认客户端。
        on_event: 可选同步回调函数，每收到一段数据时在订阅线程中调用。
            该回调只应执行轻量、非阻塞逻辑；如需耗时处理，建议改用
            Subscription.get() / drain() 在外部线程或主线程消费事件。
        chunk_size: 流式读取块大小。
        connect_timeout: 建立连接超时秒数，默认5秒。
        read_timeout: 读取数据超时秒数，默认None表示无限等待。
        encoding: 订阅流文本编码，默认gbk。
        boundary: Tinysoft消息边界，默认end。
        queue_maxsize: 事件队列最大长度。队列满时会丢弃最旧事件，优先保留最新事件。

    Returns:
        Subscription: 已启动的订阅对象。

    Examples:
        >>> import cjpy
        >>> cjpy.set_token("your-token")
        >>> sub = cjpy.subscribe(ids=["SZ000001"], fields=["price"])
        >>> event = sub.get(timeout=1)
        >>> sub.stop()

    Notes:
        内部队列默认长度为 1000。若主线程或工作线程未及时消费事件，
        新事件到来时会自动丢弃最旧事件，并通过日志记录该行为。
    """
    return Subscription(
        ids=ids,
        fields=fields,
        type_=type_,
        client=client,
        on_event=on_event,
        chunk_size=chunk_size,
        connect_timeout=connect_timeout,
        read_timeout=read_timeout,
        encoding=encoding,
        boundary=boundary,
        queue_maxsize=queue_maxsize,
        logger=logger,
    ).start()


if __name__ == "__main__":
    sub = subscribe(
        ids=["SZ000001", "SH000001"],
        fields=["StockName", "date_s", "price"],
    )

    try:
        while True:
            event = sub.get(timeout=1)
            if event is not None:
                print(event)
                print("----------------------------------------")
                if event["_event"] in {"error", "stopped"}:
                    break
    except KeyboardInterrupt:
        pass
    finally:
        sub.stop()
