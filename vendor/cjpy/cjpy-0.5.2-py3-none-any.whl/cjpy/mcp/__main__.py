# -*- coding: utf-8 -*-
"""``python -m cjpy.mcp`` 入口。"""
from cjpy.mcp.server import main

if __name__ == "__main__":
    raise SystemExit(main())
