# -*- coding: utf-8 -*-
"""MCP 工具的结构化成功响应模型。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class QueryMetadata(BaseModel):
    """查询结果的规模、字段和请求元数据。"""

    total_rows: int = Field(description="完整结果的总行数")
    returned_rows: int = Field(description="本次实际返回的行数")
    complete: bool = Field(description="本次 data 是否包含完整查询结果")
    truncated: bool = Field(description="是否因 MCP 输出上限而省略了部分或全部结果")
    result_mode: Literal["complete", "preview"] = Field(description="完整结果或显式预览模式")
    max_rows: int = Field(description="本次 MCP 响应允许内联返回的最大行数")
    columns: list[str] = Field(default_factory=list, description="表格结果的列名")
    query: dict[str, Any] = Field(default_factory=dict, description="实际查询参数摘要")


class RecordsResult(BaseModel):
    """表格型查询结果。"""

    status: Literal["ok", "empty", "too_large", "preview"] = Field(
        description="完整有数据、完整无数据、结果超限未返回，或显式预览"
    )
    data: list[dict[str, Any]] = Field(description="按行组织的记录")
    metadata: QueryMetadata
    hints: list[str] = Field(default_factory=list, description="空结果、结果超限或预览时的提示")


class ValuesResult(BaseModel):
    """字符串列表型查询结果，例如证券代码或交易日。"""

    status: Literal["ok", "empty", "too_large", "preview"] = Field(
        description="完整有数据、完整无数据、结果超限未返回，或显式预览"
    )
    data: list[str] = Field(description="字符串值列表")
    metadata: QueryMetadata
    hints: list[str] = Field(default_factory=list, description="空结果、结果超限或预览时的提示")


__all__ = ["QueryMetadata", "RecordsResult", "ValuesResult"]
