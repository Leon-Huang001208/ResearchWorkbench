# -*- coding: utf-8 -*-
"""MCP 目录型数据使用的进程内 TTL 缓存。"""

from __future__ import annotations

import threading
import time
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class _Entry:
    value: Any
    expires_at: float


class TTLCache:
    """小型线程安全 TTL 缓存；加载失败时不会写入缓存。"""

    def __init__(self) -> None:
        self._entries: dict[str, _Entry] = {}
        self._lock = threading.RLock()
        self._key_locks: dict[str, threading.Lock] = {}

    def get_or_load(self, key: str, loader: Callable[[], Any], ttl: float) -> Any:
        with self._lock:
            key_lock = self._key_locks.setdefault(key, threading.Lock())

        # 同一个 key 只允许一个加载器运行；不同 key 不会互相阻塞。
        with key_lock:
            now = time.monotonic()
            with self._lock:
                entry = self._entries.get(key)
                if entry is not None and entry.expires_at > now:
                    return deepcopy(entry.value)

            value = loader()
            stored = deepcopy(value)
            with self._lock:
                self._entries[key] = _Entry(
                    value=stored,
                    expires_at=time.monotonic() + ttl,
                )
            return deepcopy(stored)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()


catalog_cache = TTLCache()

__all__ = ["TTLCache", "catalog_cache"]
