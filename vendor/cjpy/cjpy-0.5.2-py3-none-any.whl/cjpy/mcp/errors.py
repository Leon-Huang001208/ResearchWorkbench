# -*- coding: utf-8 -*-
"""把 cjpy 异常转换为 MCP 协议级工具错误。"""
from __future__ import annotations

import functools
import logging
from typing import Callable

from cjpy.api import CjAPIError
from cjpy.base import CjConfigError, CjError, CjRequestError
from mcp.server.fastmcp.exceptions import ToolError

logger = logging.getLogger(__name__)


def to_tool_error(exc: BaseException, operation: str) -> ToolError:
    """将异常转换成包含错误类别、操作名和下一步建议的 ``ToolError``。"""
    if isinstance(exc, CjConfigError):
        return ToolError(
            f"[config_error] {operation}: {exc}。"
            "请先在可信的本地 Python 环境执行 cjpy.set_token('<token>')，"
            "或设置环境变量 cj_key，然后重启 MCP server。"
        )
    if isinstance(exc, CjRequestError):
        logger.warning("MCP tool %s: cjpy request error: %s", operation, exc)
        return ToolError(
            f"[request_error] {operation}: {exc}。"
            "请检查网络连接、token 是否过期以及数据权限。"
        )
    if isinstance(exc, CjAPIError):
        logger.warning("MCP tool %s: cjpy API contract error: %s", operation, exc)
        return ToolError(
            f"[api_error] {operation}: {exc}。"
            "服务端返回了错误信息或无法解析的数据结构，请核对查询条件后重试。"
        )
    if isinstance(exc, CjError):
        logger.warning("MCP tool %s: cjpy error: %s", operation, exc)
        return ToolError(f"[api_error] {operation}: {exc}")
    if isinstance(exc, (TypeError, ValueError)):
        return ToolError(f"[invalid_argument] {operation}: {exc}。请检查工具参数后重试。")
    logger.exception("MCP tool %s: unexpected error", operation)
    return ToolError(
        f"[internal_error] {operation}: MCP 工具发生未预期错误；"
        "详细信息已写入 server 日志。"
    )


def tool_errors(operation: str) -> Callable:
    """装饰工具函数，使所有失败通过 MCP ``isError`` 语义返回。"""

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except ToolError:
                raise
            except Exception as exc:  # noqa: BLE001
                raise to_tool_error(exc, operation) from exc

        return wrapper

    return decorator


__all__ = [
    "to_tool_error",
    "tool_errors",
]
