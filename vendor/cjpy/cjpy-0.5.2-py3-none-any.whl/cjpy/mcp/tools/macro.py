# -*- coding: utf-8 -*-
"""宏观指标数据查询工具。"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from cjpy import api as cj_api
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import RecordsResult
from cjpy.mcp.serializers import records_result
from cjpy.mcp.tools._common import MaxRows, OptionalDateText, ResultMode, clean_optional_text


@tool_errors("get_macro_data")
def get_macro_data(
    indicator: Annotated[
        str,
        Field(
            description=(
                "服务端可识别的宏观指标定位字符串，例如“指标名称@表名”或"
                "“指标ID@表ID”；应先通过 list_macro_indicators 确认。"
            )
        ),
    ],
    start: OptionalDateText = None,
    end: OptionalDateText = None,
    max_rows: MaxRows = 500,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """查询指定宏观指标的时间序列。

    推荐先调用 list_macro_tables 和 list_macro_indicators。指标名称重复时必须带上
    所属表或使用 ID 定位；日期范围及排序方式由服务端决定。
    """
    indicator_arg = indicator.strip()
    start_arg = clean_optional_text(start)
    end_arg = clean_optional_text(end)
    df = cj_api.get_macro_data(indicator_arg, start=start_arg, end=end_arg)
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"indicator": indicator_arg, "start": start_arg, "end": end_arg},
        empty_hints=["没有宏观数据；请核对指标名称、ID、所属表和日期条件。"],
    )


MACRO_TOOLS = (get_macro_data,)

__all__ = ["get_macro_data", "MACRO_TOOLS"]
