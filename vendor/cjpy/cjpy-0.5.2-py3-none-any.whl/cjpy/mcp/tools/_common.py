# -*- coding: utf-8 -*-
"""MCP 工具共享的参数类型和小型辅助函数。"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from cjpy.mcp.serializers import MAX_RETURN_ROWS

MaxRows = Annotated[
    int,
    Field(
        ge=1,
        le=MAX_RETURN_ROWS,
        description=(
            f"MCP 响应最多保留的记录数，范围 1～{MAX_RETURN_ROWS}。"
            "它只限制返回给 AI 的内容，不会减少服务端实际查询量。"
        ),
    ),
]
ResultMode = Annotated[
    Literal["complete", "preview"],
    Field(
        description=(
            "结果返回模式。complete（默认）只接受完整结果，超过 max_rows 时"
            "返回 too_large 且不返回部分数据；preview 明确允许只返回前"
            " max_rows 条，预览子集不得用于全量统计或完整集合判断。"
        )
    ),
]
Keyword = Annotated[str, Field(description="可选的普通子串关键字；留空表示不过滤")]
SecurityCode = Annotated[
    str,
    Field(
        description=(
            "单个证券代码，支持 Wind 格式（如 000001.SZ）和天软格式"
            "（如 SZ000001）。裸代码可能有交易所歧义，不应由 AI 猜测。"
        )
    ),
]
SecurityCodes = Annotated[
    str | list[str],
    Field(
        description=(
            "单个证券代码或证券代码列表；每项支持 Wind 或天软格式。"
            "大批量查询会完整发送到服务端，应优先缩小代码范围。"
        )
    ),
]
DateText = Annotated[
    str,
    Field(
        description=(
            "日期字符串，支持 YYYYMMDD 或 YYYY-MM-DD；后者由 cjpy API"
            " 规范化为服务端要求的 YYYYMMDD。"
        )
    ),
]
OptionalDateText = Annotated[
    str | None,
    Field(
        description=(
            "可选日期条件，支持 YYYYMMDD 或 YYYY-MM-DD；后者由 cjpy API"
            " 规范化为服务端要求的 YYYYMMDD。省略或留空时不限定该端范围。"
        )
    ),
]


def clean_optional_text(value: str | None) -> str | None:
    """将空白字符串转换成 ``None``，其他字符串去掉首尾空白。"""
    if value is None:
        return None
    text = value.strip()
    return text or None


__all__ = [
    "DateText",
    "Keyword",
    "MaxRows",
    "OptionalDateText",
    "ResultMode",
    "SecurityCode",
    "SecurityCodes",
    "clean_optional_text",
]
