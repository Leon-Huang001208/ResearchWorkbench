# -*- coding: utf-8 -*-
"""交易日和行情数据工具。"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from cjpy import api as cj_api
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import RecordsResult, ValuesResult
from cjpy.mcp.serializers import records_result, values_result
from cjpy.mcp.tools._common import (
    DateText,
    MaxRows,
    ResultMode,
    SecurityCode,
    clean_optional_text,
)


@tool_errors("get_trading_days")
def get_trading_days(
    start: DateText,
    end: DateText,
    cycle: Annotated[
        str,
        Field(
            description=(
                "取样周期，默认 D。常用值：D 日、W 周、M 月、Q 季、H 半年、Y 年；"
                "客户端不建立固定枚举，最终支持范围由服务端决定。"
            )
        ),
    ] = "D",
    code: Annotated[
        str | None,
        Field(
            description=(
                "可选的交易日历基准证券代码，支持 Wind 或天软格式；"
                "省略时使用 SH000001。"
            )
        ),
    ] = None,
    max_rows: MaxRows = 500,
    result_mode: ResultMode = "complete",
) -> ValuesResult:
    """获取日期区间内的交易日或周期代表交易日。

    日、周、月、季、半年和年度取样都使用本工具。start、end 的先后关系及 cycle
    是否可用由服务端判断。默认只返回完整结果；仅需样例时才使用 preview。
    """
    code_arg = clean_optional_text(code)
    values = cj_api.get_trading_days(start, end, cycle=cycle, code=code_arg)
    return values_result(
        values,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"start": start, "end": end, "cycle": cycle, "code": code_arg},
        empty_hints=["区间内没有交易日；请检查日期范围、周期和证券代码。"],
    )


@tool_errors("get_market_data")
def get_market_data(
    code: SecurityCode,
    start: DateText,
    end: DateText,
    cycle: Annotated[
        str,
        Field(
            description=(
                "K 线周期，默认 day。常用值包括 1m、5m、15m、30m、60m、"
                "120m、day；最终支持范围由服务端决定。"
            )
        ),
    ] = "day",
    rate: Annotated[
        str,
        Field(
            description=(
                "复权方式，默认不复权。常用值为不复权、前复权、后复权；"
                "最终支持范围由服务端决定。"
            )
        ),
    ] = "不复权",
    fields: Annotated[
        str | list[str] | None,
        Field(
            description=(
                "要返回的单个行情字段或字段列表。有效字段应先通过"
                " list_market_fields 发现；省略时由服务端返回默认字段。"
            )
        ),
    ] = None,
    max_rows: MaxRows = 500,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """获取单只证券在日期区间内的日线或分钟 K 线行情。

    本工具适合单证券时序行情。多证券截面对比通常使用 get_factor_data。字段名
    不确定时先调用 list_market_fields；不要根据口语名称猜测字段。
    """
    code_arg = code.strip()
    df = cj_api.get_market_data(
        code_arg,
        start,
        end,
        cycle=cycle,
        rate=rate,
        fields=fields,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={
            "code": code_arg,
            "start": start,
            "end": end,
            "cycle": cycle,
            "rate": rate,
            "fields": fields,
        },
        empty_hints=["区间内没有行情；请检查代码、上市状态、日期和字段。"],
    )


MARKET_TOOLS = (get_trading_days, get_market_data)

__all__ = [fn.__name__ for fn in MARKET_TOOLS] + ["MARKET_TOOLS"]
