# -*- coding: utf-8 -*-
"""证券板块、股票、基金和指数成分工具。"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from cjpy import api as cj_api
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import ValuesResult
from cjpy.mcp.serializers import values_result
from cjpy.mcp.tools._common import (
    MaxRows,
    OptionalDateText,
    ResultMode,
    SecurityCode,
    clean_optional_text,
)


@tool_errors("get_codes")
def get_codes(
    universe: Annotated[
        str,
        Field(
            description=(
                "证券板块名称或标识，例如 stock.a 或 fund；"
                "有效值必须先通过 list_universes 发现。"
            )
        ),
    ],
    date: OptionalDateText = None,
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> ValuesResult:
    """获取指定证券板块在某个日期的代码列表。

    已知 universe 时调用；不知道板块标识应先调用 list_universes。日期省略时
    使用 cjpy API 的默认日期。默认只返回完整列表；仅需样例时才使用 preview。
    """
    name = universe.strip()
    date_arg = clean_optional_text(date)
    values = cj_api.get_codes(name, date_arg)
    return values_result(
        values,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"universe": name, "date": date_arg},
        empty_hints=["板块在指定日期没有证券；请核对板块标识和日期。"],
    )


@tool_errors("get_stocks")
def get_stocks(
    date: Annotated[
        str | None,
        Field(
            description=(
                "可选股票截面日期，常用 YYYYMMDD 或 YYYY-MM-DD；"
                "传入 all 获取服务端维护的历史全部股票代码。"
            )
        ),
    ] = None,
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> ValuesResult:
    """获取指定日期的全 A 股代码列表。

    默认 complete 模式下，完整股票池超过 max_rows 时不返回部分代码。只需查看
    代码样例时可显式使用 preview；完整股票池和批量导出应使用 cjpy Python API。
    """
    date_arg = clean_optional_text(date)
    return values_result(
        cj_api.get_stocks(date_arg),
        max_rows=max_rows,
        result_mode=result_mode,
        query={"date": date_arg},
        empty_hints=["指定日期没有股票快照；请尝试最近交易日或 date='all'。"],
    )


@tool_errors("get_funds")
def get_funds(
    date: OptionalDateText = None,
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> ValuesResult:
    """获取指定日期的基金代码列表。

    日期省略时使用 cjpy API 默认日期。工具只返回代码，不提供基金名称搜索。
    默认只返回完整列表；仅需样例时才使用 preview。
    """
    date_arg = clean_optional_text(date)
    return values_result(
        cj_api.get_funds(date_arg),
        max_rows=max_rows,
        result_mode=result_mode,
        query={"date": date_arg},
        empty_hints=["指定日期没有基金代码；请核对日期。"],
    )


@tool_errors("get_index_constituents")
def get_index_constituents(
    code: SecurityCode,
    date: OptionalDateText = None,
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> ValuesResult:
    """获取指定指数在某个日期的成分证券代码。

    code 必须是明确的指数代码，不应根据指数简称猜测交易所或代码。日期省略时
    使用 cjpy API 默认日期。
    """
    code_arg = code.strip()
    date_arg = clean_optional_text(date)
    return values_result(
        cj_api.get_index_constituents(code_arg, date_arg),
        max_rows=max_rows,
        result_mode=result_mode,
        query={"code": code_arg, "date": date_arg},
        empty_hints=["没有成分股数据；请核对指数代码、日期及服务端支持范围。"],
    )


SECURITY_TOOLS = (
    get_codes,
    get_stocks,
    get_funds,
    get_index_constituents,
)

__all__ = [fn.__name__ for fn in SECURITY_TOOLS] + ["SECURITY_TOOLS"]
