# -*- coding: utf-8 -*-
"""注册新版 cjpy MCP 工具。"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from cjpy.mcp.tools.discovery import DISCOVERY_TOOLS
from cjpy.mcp.tools.factors import FACTOR_TOOLS
from cjpy.mcp.tools.macro import MACRO_TOOLS
from cjpy.mcp.tools.market import MARKET_TOOLS
from cjpy.mcp.tools.securities import SECURITY_TOOLS
from cjpy.mcp.tools.tables import TABLE_TOOLS

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

ALL_TOOLS: tuple[Callable[..., Any], ...] = (
    *DISCOVERY_TOOLS,
    *SECURITY_TOOLS,
    *MARKET_TOOLS,
    *TABLE_TOOLS,
    *FACTOR_TOOLS,
    *MACRO_TOOLS,
)

MCP_TOOL_NAMES = frozenset(fn.__name__ for fn in ALL_TOOLS)
CORE_API_TOOL_NAMES = MCP_TOOL_NAMES - {"describe_python_api"}


def register_all_tools(server: "FastMCP") -> None:
    """将所有工具注册到 FastMCP，输入和输出 Schema 均由类型注解生成。"""
    from mcp.types import ToolAnnotations

    for fn in ALL_TOOLS:
        server.tool(
            structured_output=True,
            annotations=ToolAnnotations(
                readOnlyHint=True,
                destructiveHint=False,
                idempotentHint=True,
                openWorldHint=fn.__name__ != "describe_python_api",
            ),
        )(fn)


__all__ = [
    "ALL_TOOLS",
    "CORE_API_TOOL_NAMES",
    "MCP_TOOL_NAMES",
    "register_all_tools",
]
