# -*- coding: utf-8 -*-
"""文档、板块、字段、因子和宏观目录发现工具。"""

from __future__ import annotations

from typing import Annotated, Any

from pydantic import Field

from cjpy import api as cj_api
from cjpy.introspection import describe_api as _describe_python_api
from cjpy.mcp.cache import catalog_cache
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import RecordsResult
from cjpy.mcp.serializers import filter_dataframe, records_result
from cjpy.mcp.tools._common import Keyword, MaxRows, ResultMode, clean_optional_text

_CATALOG_TTL_SECONDS = 600


def _cached(key: str, loader):
    return catalog_cache.get_or_load(key, loader, _CATALOG_TTL_SECONDS)


@tool_errors("describe_python_api")
def describe_python_api(
    function: Annotated[
        str | None,
        Field(
            description=(
                "要查看的 cjpy Python 函数名，例如 get_market_data；"
                "省略或留空时返回全部 Python 查询接口目录。"
            )
        ),
    ] = None,
) -> dict[str, Any]:
    """查看 cjpy Python 函数的签名、参数、返回值和示例。

    仅在需要编写或解释 cjpy Python 代码时调用。它描述的是 Python API，
    不是 MCP 工具；MCP 工具的用法应以工具自身的输入、输出 Schema 为准。
    """
    return _describe_python_api(clean_optional_text(function))


@tool_errors("list_universes")
def list_universes(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现 get_codes 可使用的证券板块名称或标识。

    不知道 universe 时应先调用本工具，不要猜测板块标识。keyword 会在已获取的
    目录中做普通子串过滤。默认只返回完整结果；仅需样例时才使用 preview。
    """
    df = filter_dataframe(_cached("universes", cj_api.list_universes), keyword)
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配的板块；可清空 keyword 查看全部板块。"],
    )


@tool_errors("list_market_fields")
def list_market_fields(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现 get_market_data 可使用的正式行情字段。

    字段名必须以本工具返回的服务端目录为准。keyword 是普通子串过滤，留空可查看
    完整目录。默认只返回完整结果；仅需样例时才使用 preview。
    """
    df = filter_dataframe(_cached("market_fields", cj_api.list_market_fields), keyword)
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配的行情字段；可清空 keyword 查看全部字段。"],
    )


@tool_errors("list_tables")
def list_tables(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现 get_table_data 当前可查询的服务端结构化数据表。

    目录范围由服务端决定，不限于财务或基本面数据。查询 get_table_data 前应先
    确定精确表名，再用 list_table_fields 发现字段。
    """
    df = filter_dataframe(_cached("tables", cj_api.list_tables), keyword)
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配的数据表；可清空 keyword 查看全部表。"],
    )


@tool_errors("list_table_fields")
def list_table_fields(
    table_name: Annotated[
        str,
        Field(description="服务端正式表名；应来自 list_tables 的返回结果。"),
    ],
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现指定数据表可用于 get_table_data 的正式字段名。

    table_name 应来自 list_tables。不要把口语指标名称直接当作字段名。
    """
    if not table_name.strip():
        raise ValueError("table_name 不能为空")
    name = table_name.strip()
    df = filter_dataframe(
        _cached(f"table_fields:{name}", lambda: cj_api.list_table_fields(name)),
        keyword,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"table_name": name, "keyword": keyword},
        empty_hints=["没有找到匹配字段；请核对表名或清空 keyword 查看全部字段。"],
    )


@tool_errors("list_factors")
def list_factors(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现 get_factor_data 可直接使用的服务端预定义因子名称。

    keyword 会搜索因子目录的全部列。自定义因子不在这里，应通过 repo 显式定义。
    """
    df = filter_dataframe(
        _cached("factors", cj_api.list_factors).reset_index(),
        keyword,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配因子；可清空 keyword 查看全部因子。"],
    )


@tool_errors("list_macro_tables")
def list_macro_tables(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现宏观指标所属的服务端数据表。

    宏观指标名称可能重复；应结合本工具和 list_macro_indicators 确定所属表。
    """
    df = filter_dataframe(_cached("macro_tables", cj_api.list_macro_tables), keyword)
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配的宏观数据表。"],
    )


@tool_errors("list_macro_indicators")
def list_macro_indicators(
    keyword: Keyword = "",
    max_rows: MaxRows = 200,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """发现 get_macro_data 可使用的宏观指标名称、ID 及所属表。

    名称不唯一时应使用“指标名称@表名”或服务端支持的 ID 组合定位。
    """
    df = filter_dataframe(
        _cached("macro_indicators", cj_api.list_macro_indicators),
        keyword,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={"keyword": keyword},
        empty_hints=["没有找到匹配的宏观指标。"],
    )


DISCOVERY_TOOLS = (
    describe_python_api,
    list_universes,
    list_market_fields,
    list_tables,
    list_table_fields,
    list_factors,
    list_macro_tables,
    list_macro_indicators,
)

__all__ = [fn.__name__ for fn in DISCOVERY_TOOLS] + ["DISCOVERY_TOOLS"]
