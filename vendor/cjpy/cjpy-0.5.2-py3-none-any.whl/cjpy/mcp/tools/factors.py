# -*- coding: utf-8 -*-
"""因子数据查询工具。"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from cjpy import api as cj_api
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import RecordsResult
from cjpy.mcp.serializers import records_result
from cjpy.mcp.tools._common import MaxRows, ResultMode, SecurityCodes


@tool_errors("get_factor_data")
def get_factor_data(
    code: SecurityCodes,
    date: Annotated[
        str | list[str],
        Field(
            description=(
                "单个截面日期或日期列表，常用 YYYYMMDD 或 YYYY-MM-DD。"
                "代码数×日期数×因子数决定查询规模。"
            )
        ),
    ],
    factors: Annotated[
        str | list[str],
        Field(
            description=(
                "单个因子名称或因子名称列表。预定义名称应先通过 list_factors"
                " 确认；自定义名称必须同时出现在 repo 的键中。"
            )
        ),
    ],
    repo: Annotated[
        dict[str, str] | None,
        Field(
            description=(
                "可选自定义因子库：键是 factors 中引用的因子名称，值是天软公式。"
                "仅查询预定义因子时省略。"
            )
        ),
    ] = None,
    max_rows: MaxRows = 500,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """查询证券在一个或多个截面日期的预定义或自定义因子值。

    因子名不确定时先调用 list_factors。大规模请求应减少代码、日期或因子数量；
    默认只返回完整结果；仅需样例时才使用 preview。max_rows 和 result_mode 都
    不会减少服务端计算量。
    """
    df = cj_api.get_factor_data(
        code=code,
        date=date,
        factors=factors,
        repo=repo,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={
            "code": code,
            "date": date,
            "factors": factors,
            "custom_factors": list(repo) if repo else [],
        },
        empty_hints=["没有因子数据；请先用 list_factors 核对因子名，并检查代码和日期。"],
    )


FACTOR_TOOLS = (get_factor_data,)

__all__ = ["get_factor_data", "FACTOR_TOOLS"]
