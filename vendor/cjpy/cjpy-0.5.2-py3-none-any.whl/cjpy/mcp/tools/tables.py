# -*- coding: utf-8 -*-
"""财务和基本面数据表查询工具。"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from cjpy import api as cj_api
from cjpy.mcp.errors import tool_errors
from cjpy.mcp.models import RecordsResult
from cjpy.mcp.serializers import records_result
from cjpy.mcp.tools._common import (
    MaxRows,
    OptionalDateText,
    ResultMode,
    SecurityCodes,
    clean_optional_text,
)


@tool_errors("get_table_data")
def get_table_data(
    code: SecurityCodes,
    table_name: Annotated[
        str,
        Field(description="服务端正式数据表名；必须先通过 list_tables 确认。"),
    ],
    fields: Annotated[
        str | list[str] | None,
        Field(
            description=(
                "要返回的单个字段名或字段列表。必须使用 list_table_fields 返回的"
                "正式字段名；省略时由服务端返回默认字段。"
            )
        ),
    ] = None,
    start: OptionalDateText = None,
    end: OptionalDateText = None,
    max_rows: MaxRows = 500,
    result_mode: ResultMode = "complete",
) -> RecordsResult:
    """按代码查询 list_tables 目录中的服务端结构化数据表。

    本工具不限于财务或基本面数据。推荐顺序是
    list_tables → list_table_fields → get_table_data。不同表使用不同代码类型和
    日期字段；start、end 是否参与过滤由具体服务端表决定。
    """
    name = table_name.strip()
    start_arg = clean_optional_text(start)
    end_arg = clean_optional_text(end)
    df = cj_api.get_table_data(
        code=code,
        table_name=name,
        fields=fields,
        start=start_arg,
        end=end_arg,
    )
    return records_result(
        df,
        max_rows=max_rows,
        result_mode=result_mode,
        query={
            "code": code,
            "table_name": name,
            "fields": fields,
            "start": start_arg,
            "end": end_arg,
        },
        empty_hints=[
            "目标表没有记录；请用 list_tables 和 list_table_fields 核对表名与字段名，"
            "并检查代码类型和日期条件。"
        ],
    )


TABLE_TOOLS = (get_table_data,)

__all__ = ["get_table_data", "TABLE_TOOLS"]
