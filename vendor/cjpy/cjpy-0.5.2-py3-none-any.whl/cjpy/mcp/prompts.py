# -*- coding: utf-8 -*-
"""面向常见投研小任务的 MCP Prompt。"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Annotated

from pydantic import Field

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


CodeText = Annotated[
    str,
    Field(
        description=(
            "明确的证券代码，支持天软格式（如 SZ000001）或 Wind 格式"
            "（如 000001.SZ）；不要填写存在歧义的简称。"
        )
    ),
]
CodesText = Annotated[
    str,
    Field(
        description=(
            "要比较的多个明确证券代码，用逗号或空格分隔；"
            "支持天软格式或 Wind 格式。"
        )
    ),
]
StartText = Annotated[
    str,
    Field(description="可选开始日期，常用 YYYYMMDD 或 YYYY-MM-DD；留空表示不限定。"),
]
EndText = Annotated[
    str,
    Field(description="可选结束日期，常用 YYYYMMDD 或 YYYY-MM-DD；留空表示不限定。"),
]

_COMMON_RULES = """
共同执行规则：
1. 只使用当前 cjpy MCP 工具的 Schema 和返回结果；不得猜测证券代码、正式表名、
   字段名、因子名或宏观指标定位字符串。
2. 目录或字段不明确时，先调用对应的 list_* 发现工具，再调用数据工具。
3. 用于分析的数据必须采用 result_mode="complete"，并检查 status、
   metadata.complete、数据日期和缺失值。status="too_large" 时缩小或拆分查询；
   preview 只能了解样例，不能据此统计、排名或形成结论。
4. status="empty" 时根据 hints 检查参数；仍无法确定时说明缺少什么信息，不得补造
   数据。
5. 输出中分开陈述“数据事实”“明确展示公式的简单计算”和“基于数据的解释”，并
   标注数据截止日期、复权方式、报告期或其他关键口径。
6. 不提供涨跌预测、目标价或买卖建议；结尾列出数据限制和未覆盖的信息。
""".strip()


def _input(value: str) -> str:
    """把空参数统一呈现为未指定，方便 Prompt 模板阅读。"""
    clean = value.strip()
    return clean or "未指定"


def company_research_snapshot(
    code: CodeText,
    date: Annotated[
        str,
        Field(
            description=(
                "可选研究截面日期；留空时通过交易日工具确定不晚于当前日期的"
                "最近可用交易日。"
            )
        ),
    ] = "",
    dimensions: Annotated[
        str,
        Field(
            description=(
                "希望覆盖的研究维度，用逗号分隔；"
                "默认包括基本信息、估值、盈利和成长。"
            )
        ),
    ] = "基本信息、估值、盈利、成长",
) -> str:
    """生成单只证券的基础投研快照。"""
    return f"""
请使用 cjpy MCP 为指定证券制作一份可核验的基础投研快照。

用户输入：
- 证券代码：{_input(code)}
- 研究截面日期：{_input(date)}
- 研究维度：{_input(dimensions)}

执行步骤：
1. 检查代码是否明确；若只有简称、裸代码或存在交易所歧义，先向用户确认。
2. 日期未指定时，调用 get_trading_days 确定不晚于当前日期的最近可用交易日。
3. 使用 list_tables 和 list_table_fields 发现股票基本信息及所需财务表，随后用
   get_table_data 查询与研究维度直接相关的少量字段。
4. 对估值、盈利、成长等维度分别使用 list_factors 搜索正式因子名，再用
   get_factor_data 查询同一截面日期；若存在多个相近因子，说明选择依据。
5. 不为凑齐模板而选择语义不确定的字段或因子。缺少某个维度时明确标为不可得。

输出格式：
- 证券与数据日期
- 公司/证券基本信息
- 估值
- 盈利能力
- 成长情况
- 基于上述数据的简短观察
- 数据口径、缺失项与限制

{_COMMON_RULES}
""".strip()


def peer_factor_comparison(
    codes: CodesText,
    date: Annotated[
        str,
        Field(
            description=(
                "可选比较截面日期；留空时通过交易日工具确定不晚于当前日期的"
                "最近可用交易日。"
            )
        ),
    ] = "",
    dimensions: Annotated[
        str,
        Field(description="比较维度，用逗号分隔；默认包括估值、盈利、成长和质量。"),
    ] = "估值、盈利、成长、质量",
    focus: Annotated[
        str,
        Field(description="可选的特别关注点；留空表示按所有维度均衡展示。"),
    ] = "",
) -> str:
    """在同一截面比较多只证券的因子表现。"""
    return f"""
请使用 cjpy MCP 完成多只证券在同一日期的因子横向比较。

用户输入：
- 证券代码：{_input(codes)}
- 比较日期：{_input(date)}
- 比较维度：{_input(dimensions)}
- 特别关注：{_input(focus)}

执行步骤：
1. 将代码解析为明确列表；有歧义或代码数量过多时先请用户确认或缩小范围。
2. 日期未指定时，调用 get_trading_days 确定统一的最近可用交易日。
3. 按每个维度调用 list_factors，选择语义最贴近且可比的正式因子。记录因子
   名称，不得把不同口径指标混为一项。
4. 使用一次或少量 get_factor_data 请求获取同一日期、同一组因子的完整截面。
5. 仅在数值方向含义明确时比较高低；例如估值倍数较低不自动等同于“更好”。
6. 除非用户给出权重和评分规则，否则不计算综合总分或总排名。

输出格式：
- 比较日期及实际使用的因子定义
- 原始指标横向对比表
- 各维度的相对高低和突出差异
- 与用户关注点相关的观察
- 缺失值、不可比口径和数据限制

{_COMMON_RULES}
""".strip()


def financial_trend_brief(
    code: CodeText,
    start: StartText = "",
    end: EndText = "",
    topics: Annotated[
        str,
        Field(
            description=(
                "要跟踪的财务主题，用逗号分隔；"
                "默认包括收入、利润、现金流和盈利能力。"
            )
        ),
    ] = "收入、利润、现金流、盈利能力",
    periods: Annotated[
        str,
        Field(description="希望展示的报告期范围，例如“最近8个报告期”。"),
    ] = "最近8个报告期",
) -> str:
    """整理单家公司多个报告期的财务变化。"""
    return f"""
请使用 cjpy MCP 制作指定公司的财务趋势简报。

用户输入：
- 证券代码：{_input(code)}
- 开始日期：{_input(start)}
- 结束日期：{_input(end)}
- 财务主题：{_input(topics)}
- 展示范围：{_input(periods)}

执行步骤：
1. 使用 list_tables 按财务主题寻找正式数据表，并阅读其日期字段说明。
2. 对候选表调用 list_table_fields，只选择能够直接支持目标主题的正式字段。
3. 使用 get_table_data 获取完整结果。start、end 对静态表可能无效；必须根据
   list_tables 返回的信息确认它们约束的是哪个日期字段。
4. 优先保留用户指定范围内最近的报告期，并按报告期而不是返回行顺序整理。
5. 只有在期间和口径一致、数据完整时才计算同比或环比，并展示计算所使用的两期
   数值；不得将累计值直接当作单季度值比较。
6. 比较经营现金流与利润时只陈述数据匹配关系，不推断未被数据支持的原因。

输出格式：
- 实际使用的数据表、字段和日期口径
- 最近若干报告期核心数据表
- 收入与利润趋势
- 现金流与盈利质量观察
- 明显变化及其对应报告期
- 缺失值、口径差异和数据限制

{_COMMON_RULES}
""".strip()


def macro_indicator_brief(
    indicator: Annotated[
        str,
        Field(description="要跟踪的宏观指标名称、关键词或明确的指标定位字符串。"),
    ],
    start: StartText = "",
    end: EndText = "",
    focus: Annotated[
        str,
        Field(description="可选关注点，例如趋势、同比变化或近期拐点。"),
    ] = "趋势和近期变化",
) -> str:
    """跟踪一个宏观指标的历史走势和近期变化。"""
    return f"""
请使用 cjpy MCP 制作指定宏观指标的跟踪简报。

用户输入：
- 指标或关键词：{_input(indicator)}
- 开始日期：{_input(start)}
- 结束日期：{_input(end)}
- 关注点：{_input(focus)}

执行步骤：
1. 先调用 list_macro_tables 了解相关主题，再用 list_macro_indicators 搜索正式
   指标。若同名或近似指标属于不同表，列出差异并请用户确认，不得自行猜选。
2. 用“指标名称@表名”或“指标ID@表ID”等唯一定位字符串调用 get_macro_data。
3. 识别实际数据频率、单位、最新观测日期和可能的发布滞后。
4. 仅在频率一致且有对应历史值时计算简单的同比或环比，并展示公式所用数据。
5. 识别趋势变化时说明观察区间和依据，不把短期波动直接称为确定拐点。

输出格式：
- 最终选用的指标、所属表、单位与频率
- 最新值和最新观测日期
- 近期时间序列表
- 趋势、同比/环比或阶段变化
- 发布滞后、缺失数据和解释限制

{_COMMON_RULES}
""".strip()


def fund_holdings_snapshot(
    fund_code: Annotated[
        str,
        Field(description="明确的基金代码，支持服务端可识别的天软或 Wind 格式。"),
    ],
    report_date: Annotated[
        str,
        Field(
            description=(
                "可选报告期或截止日期，常用 YYYYMMDD 或 YYYY-MM-DD；"
                "留空时查询最近可得报告期。"
            )
        ),
    ] = "",
    compare_with_previous: Annotated[
        str,
        Field(description="是否与上一可比报告期比较，填写“是”或“否”，默认“是”。"),
    ] = "是",
) -> str:
    """整理基金持仓及其相对上一报告期的变化。"""
    return f"""
请使用 cjpy MCP 制作指定基金的持仓快照。

用户输入：
- 基金代码：{_input(fund_code)}
- 报告期：{_input(report_date)}
- 是否与上一期比较：{_input(compare_with_previous)}

执行步骤：
1. 使用 list_tables 查找基金基本信息和持仓相关正式表，确认表支持的基金代码类型
   以及报告期、截止日或公告日字段。
2. 使用 list_table_fields 确认证券代码、证券名称、持仓数量、持仓市值、持仓权重
   和报告期等实际可用字段。
3. 调用 get_table_data 获取目标报告期的完整持仓。日期未指定时依据实际返回日期
   选择最近可得报告期，不得把公告日误作持仓截止日。
4. 需要比较时，用完全相同的表和字段查询上一可比报告期。
5. 只有权重字段完整且单位一致时才汇总前十大持仓集中度，并展示参与汇总的权重。
6. 新增、退出、增持和减持必须以两个可比报告期的实际记录为依据。没有行业字段时
   不猜测行业归属。

输出格式：
- 基金及报告期
- 前十大持仓表
- 可计算时的前十大持仓集中度
- 与上一可比报告期的持仓变化
- 字段口径、披露时滞、缺失项和限制

{_COMMON_RULES}
""".strip()


def price_period_review(
    code: CodeText,
    start: Annotated[
        str,
        Field(description="复盘开始日期，常用 YYYYMMDD 或 YYYY-MM-DD。"),
    ],
    end: Annotated[
        str,
        Field(description="复盘结束日期，常用 YYYYMMDD 或 YYYY-MM-DD。"),
    ],
    benchmark_code: Annotated[
        str,
        Field(description="可选基准证券代码；留空时不进行基准对比。"),
    ] = "",
    cycle: Annotated[
        str,
        Field(description="行情周期，默认 day；应使用 get_market_data 支持的周期。"),
    ] = "day",
    rate: Annotated[
        str,
        Field(description="复权方式，默认前复权；证券与基准必须采用相同方式。"),
    ] = "前复权",
) -> str:
    """复盘单只证券在指定区间的基础价格表现。"""
    return f"""
请使用 cjpy MCP 完成指定证券的区间行情复盘。

用户输入：
- 证券代码：{_input(code)}
- 开始日期：{_input(start)}
- 结束日期：{_input(end)}
- 基准代码：{_input(benchmark_code)}
- 行情周期：{_input(cycle)}
- 复权方式：{_input(rate)}

执行步骤：
1. 使用 list_market_fields 确认日期、开盘、最高、最低、收盘和成交量等正式字段；
   只请求实际存在且本任务需要的字段。
2. 使用 get_market_data 查询目标证券的完整区间行情。若超过 500 行，优先请用户
   缩短区间或提高周期，不得用 preview 代表完整区间。
3. 如提供基准代码，用完全相同的日期、周期、复权方式和字段另行查询基准。
4. 可以计算区间首尾收盘价涨跌幅、区间最高/最低值及其日期，并展示计算公式和
   原始数值。没有可靠计算工具时，不计算最大回撤、波动率、Beta 等复杂统计量。
5. 基准对比只比较共同拥有有效数据的区间，并明确两者的实际首尾日期。

输出格式：
- 查询范围、周期和复权方式
- 首尾价格、区间涨跌、最高/最低及对应日期
- 成交量的可观察变化
- 可选的同期基准简单对比
- 基于价格数据的客观复盘
- 停牌、缺失记录、计算能力和数据口径限制

{_COMMON_RULES}
""".strip()


ALL_PROMPTS: tuple[Callable[..., str], ...] = (
    company_research_snapshot,
    peer_factor_comparison,
    financial_trend_brief,
    macro_indicator_brief,
    fund_holdings_snapshot,
    price_period_review,
)

PROMPT_TITLES = {
    "company_research_snapshot": "公司快速研究卡片",
    "peer_factor_comparison": "多证券因子对比",
    "financial_trend_brief": "公司财务趋势简报",
    "macro_indicator_brief": "宏观指标跟踪简报",
    "fund_holdings_snapshot": "基金持仓快照",
    "price_period_review": "区间行情复盘",
}


def register_all_prompts(server: "FastMCP") -> None:
    """将全部投研 Prompt 注册到 FastMCP Server。"""
    for fn in ALL_PROMPTS:
        server.prompt(
            name=fn.__name__,
            title=PROMPT_TITLES[fn.__name__],
            description=fn.__doc__,
        )(fn)


__all__ = [
    "ALL_PROMPTS",
    "PROMPT_TITLES",
    "register_all_prompts",
] + [fn.__name__ for fn in ALL_PROMPTS]
