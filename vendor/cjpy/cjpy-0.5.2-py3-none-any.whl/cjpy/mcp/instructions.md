# cjpy MCP 使用原则

cjpy MCP 提供天软证券代码、交易日、行情、服务端结构化数据表、因子和宏观数据。
它面向交互式数据查询，不是批量数据导出通道，也不提供投资建议或涨跌预测。

## 先区分两类文档

- MCP 工具的调用方法以工具自身的输入 Schema、输出 Schema 和说明为准。
- 需要编写 cjpy Python 代码时，调用 `describe_python_api`，或读取
  `cjpy://docs/api`、`cjpy://docs/api/{function}`。这些内容描述 Python API，
  不是 MCP 工具参数。

## 推荐工作流

1. 不知道板块标识时，先调用 `list_universes`，再调用 `get_codes`。
2. 不知道行情字段时，先调用 `list_market_fields`，再调用 `get_market_data`。
3. 服务端结构化数据表查询应按
   `list_tables` → `list_table_fields` → `get_table_data` 的顺序进行。
4. 因子查询前调用 `list_factors` 确认预定义因子名称；自定义因子通过 `repo`
   显式提供名称和天软公式。
5. 宏观查询先用 `list_macro_tables`、`list_macro_indicators` 确认指标及所属表，
   再调用 `get_macro_data`。
6. `status="empty"` 表示查询成功但没有数据，应结合 `hints` 检查代码、日期、
   表名、字段或权限。
7. 工具默认使用 `result_mode="complete"`。完整结果超过 `max_rows` 时返回
   `status="too_large"` 和空 `data`，不会把部分结果交给 AI；此时应缩小查询
   范围或改用 Python API。
8. 只有用户明确需要查看样例时才使用 `result_mode="preview"`。返回
   `status="preview"` 时，`data` 只是前若干条，不得用于全量统计、排名或完整
   集合判断。

## 证券代码与日期

- 证券代码支持天软格式（`SZ000001`）和 Wind 格式（`000001.SZ`）。
- 裸代码和证券名称可能有交易所歧义。MCP 不提供证券名称搜索，不要猜测；信息
  不足时应向用户确认明确代码。
- 日期支持 `YYYYMMDD` 或 `YYYY-MM-DD`；cjpy API 会把后一种规范化为服务端
  要求的 `YYYYMMDD`。日期真实性、起止顺序、周期和复权方式是否有效由服务端
  判断。

## 输出上限

- `max_rows` 是 MCP 可以内联返回的完整结果上限，范围为 1～500。默认 complete
  模式超限时不返回部分数据。
- `result_mode="preview"` 会显式返回前 `max_rows` 条；预览只用于了解数据结构或
  样例。
- `max_rows` 和 `result_mode` 都不会减少服务端查询量。
- MCP 不提供 offset 翻页，因为底层 API 没有服务端分页能力。
- 大规模历史数据、全市场代码或批量导出应改用 cjpy Python API，并在代码中分批
  查询和落盘。

## 重要业务语义

- `get_market_data` 查询单只证券的时序行情；多证券截面对比通常使用
  `get_factor_data`。
- `get_table_data` 必须使用服务端正式表名和字段名，不自动把口语指标扩展为多个
  不同字段。
- 表格日期列因表而异，应根据实际返回列选择 `公布日`、`数据报告期`、`截止日`
  或其他日期列。
- 自定义因子 `repo` 的键必须与 `factors` 中引用的自定义因子名称一致。
- 不要要求用户在对话中发送 token。token 应在可信的本地环境通过
  `cjpy.set_token(...)` 或环境变量 `cj_key` 配置。

## 能力边界

实时订阅和组合回测不属于本 MCP 工具集，可分别通过 Python API
`cjpy.subscribe` 和 `cjpy.research.Backtest` 使用。
