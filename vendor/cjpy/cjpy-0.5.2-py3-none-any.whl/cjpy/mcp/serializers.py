# -*- coding: utf-8 -*-
"""将 cjpy API 返回值转换为 MCP 结构化成功响应。"""

from __future__ import annotations

import json
import math
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Literal

import pandas as pd

from cjpy.mcp.models import QueryMetadata, RecordsResult, ValuesResult

MAX_RETURN_ROWS = 500
ResultModeValue = Literal["complete", "preview"]


def _sanitize(value: Any) -> Any:
    """递归转换成 JSON 可序列化值，并将缺失值和无穷值转换为 ``None``。"""
    if value is None:
        return None
    if value is pd.NaT or value is pd.NA:
        return None
    if isinstance(value, pd.Timestamp):
        if pd.isna(value):
            return None
        return value.isoformat(sep=" ")
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return _sanitize(float(value))
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {str(k): _sanitize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize(v) for v in value]

    # numpy 标量等通常提供 item()；转换后再走一次清洗。
    item = getattr(value, "item", None)
    if callable(item):
        try:
            converted = item()
        except (TypeError, ValueError):
            converted = value
        if converted is not value:
            return _sanitize(converted)

    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    try:
        json.dumps(value, allow_nan=False)
    except (TypeError, ValueError, OverflowError):
        return str(value)
    return value


def _validate_max_rows(max_rows: int) -> None:
    if (
        not isinstance(max_rows, int)
        or isinstance(max_rows, bool)
        or not 1 <= max_rows <= MAX_RETURN_ROWS
    ):
        raise ValueError(f"max_rows 必须是 1 到 {MAX_RETURN_ROWS} 之间的整数")


def _validate_result_mode(result_mode: str) -> None:
    if result_mode not in {"complete", "preview"}:
        raise ValueError("result_mode 必须是 'complete' 或 'preview'")


def _metadata(
    *,
    total: int,
    returned: int,
    result_mode: ResultModeValue,
    max_rows: int,
    columns: list[str] | None,
    query: dict[str, Any] | None,
) -> QueryMetadata:
    return QueryMetadata(
        total_rows=total,
        returned_rows=returned,
        complete=returned == total,
        truncated=returned < total,
        result_mode=result_mode,
        max_rows=max_rows,
        columns=columns or [],
        query=_sanitize(query or {}),
    )


def _records_overflow_result(
    *,
    total: int,
    columns: list[str],
    max_rows: int,
    query: dict[str, Any] | None,
) -> RecordsResult:
    return RecordsResult(
        status="too_large",
        data=[],
        metadata=_metadata(
            total=total,
            returned=0,
            result_mode="complete",
            max_rows=max_rows,
            columns=columns,
            query=query,
        ),
        hints=[
            f"完整结果有 {total} 行，超过本次允许的 {max_rows} 行，"
            "因此没有返回部分数据。请缩小代码、日期、字段或关键字范围；"
            "如只需查看样例，可显式设置 result_mode='preview'。"
            "批量导出请使用 cjpy Python API。"
        ],
    )


def records_result(
    value: pd.DataFrame | list[dict[str, Any]] | dict[str, Any] | None,
    *,
    max_rows: int = 200,
    result_mode: ResultModeValue = "complete",
    query: dict[str, Any] | None = None,
    empty_hints: list[str] | None = None,
) -> RecordsResult:
    """把 DataFrame 或记录集合转换为完整结果或显式预览。"""
    _validate_max_rows(max_rows)
    _validate_result_mode(result_mode)
    if value is None:
        records: list[dict[str, Any]] = []
        columns: list[str] = []
        total = 0
    elif isinstance(value, pd.DataFrame):
        columns = [str(column) for column in value.columns]
        total = len(value)
        if total > max_rows and result_mode == "complete":
            return _records_overflow_result(
                total=total,
                columns=columns,
                max_rows=max_rows,
                query=query,
            )
        frame = value if total <= max_rows else value.head(max_rows)
        records = frame.to_dict(orient="records")
    elif isinstance(value, dict):
        try:
            frame = pd.DataFrame(value)
        except (TypeError, ValueError):
            records = [value]
            columns = [str(key) for key in value]
            total = 1
        else:
            columns = [str(column) for column in frame.columns]
            total = len(frame)
            if total > max_rows and result_mode == "complete":
                return _records_overflow_result(
                    total=total,
                    columns=columns,
                    max_rows=max_rows,
                    query=query,
                )
            frame = frame if total <= max_rows else frame.head(max_rows)
            records = frame.to_dict(orient="records")
    else:
        total = len(value)
        columns = [str(key) for key in value[0]] if value else []
        if total > max_rows and result_mode == "complete":
            return _records_overflow_result(
                total=total,
                columns=columns,
                max_rows=max_rows,
                query=query,
            )
        records = list(value if total <= max_rows else value[:max_rows])

    sanitized = [_sanitize(record) for record in records]
    meta = _metadata(
        total=total,
        returned=len(sanitized),
        result_mode=result_mode,
        max_rows=max_rows,
        columns=columns,
        query=query,
    )
    hints = list(empty_hints or []) if total == 0 else []
    status: Literal["ok", "empty", "preview"]
    if total == 0:
        status = "empty"
    elif meta.truncated:
        status = "preview"
        hints.append(
            f"完整结果有 {total} 行，当前显式预览前 {len(sanitized)} 行；"
            "该子集不得用于全量统计、排名或完整集合判断。"
        )
    else:
        status = "ok"
    return RecordsResult(
        status=status,
        data=sanitized,
        metadata=meta,
        hints=hints,
    )


def values_result(
    values: list[Any] | None,
    *,
    max_rows: int = 200,
    result_mode: ResultModeValue = "complete",
    query: dict[str, Any] | None = None,
    empty_hints: list[str] | None = None,
) -> ValuesResult:
    """把标量列表转换为完整结果或显式预览。"""
    _validate_max_rows(max_rows)
    _validate_result_mode(result_mode)
    source = [] if values is None else values
    total = len(source)
    if total > max_rows and result_mode == "complete":
        return ValuesResult(
            status="too_large",
            data=[],
            metadata=_metadata(
                total=total,
                returned=0,
                result_mode=result_mode,
                max_rows=max_rows,
                columns=[],
                query=query,
            ),
            hints=[
                f"完整结果有 {total} 项，超过本次允许的 {max_rows} 项，"
                "因此没有返回部分数据。请缩小查询范围；"
                "如只需查看样例，可显式设置 result_mode='preview'。"
                "批量导出请使用 cjpy Python API。"
            ],
        )
    selected = source if total <= max_rows else source[:max_rows]
    page = [str(item) for item in selected]
    meta = _metadata(
        total=total,
        returned=len(page),
        result_mode=result_mode,
        max_rows=max_rows,
        columns=[],
        query=query,
    )
    hints = list(empty_hints or []) if total == 0 else []
    status: Literal["ok", "empty", "preview"]
    if total == 0:
        status = "empty"
    elif meta.truncated:
        status = "preview"
        hints.append(
            f"完整结果有 {total} 项，当前显式预览前 {len(page)} 项；"
            "该子集不得用于完整集合判断。"
        )
    else:
        status = "ok"
    return ValuesResult(
        status=status,
        data=page,
        metadata=meta,
        hints=hints,
    )


def filter_dataframe(df: pd.DataFrame, keyword: str) -> pd.DataFrame:
    """对 DataFrame 的所有列做不区分大小写的普通子串过滤。"""
    text = keyword.strip()
    if not text or df.empty:
        return df
    mask = pd.Series(False, index=df.index)
    for column in df.columns:
        mask = mask | df[column].astype(str).str.contains(text, case=False, regex=False, na=False)
    return df[mask]


__all__ = [
    "MAX_RETURN_ROWS",
    "filter_dataframe",
    "records_result",
    "values_result",
]
