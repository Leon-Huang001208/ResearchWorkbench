# -*- coding: utf-8 -*-
"""将 cjpy 查询 API 暴露为结构化 FastMCP 工具。"""
from cjpy.mcp.server import create_server, main

__all__ = ["create_server", "main"]
