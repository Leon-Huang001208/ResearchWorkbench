# -*- coding: utf-8 -*-
"""cjpy MCP Server：单一 FastMCP 实现和命令行入口。"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

_INSTRUCTIONS_FILE = Path(__file__).parent / "instructions.md"
_LOGGER = logging.getLogger(__name__)
_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


def _log_level_name() -> str:
    value = os.getenv("CJPY_MCP_LOG_LEVEL", "WARNING").upper()
    return value if value in _LOG_LEVELS else "WARNING"


def _configure_utf8() -> None:
    """确保 stdio 协议和日志在 Windows 上使用 UTF-8。"""
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for name in ("stdin", "stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


def _configure_logging() -> None:
    level_name = _log_level_name()
    level = getattr(logging, level_name, logging.WARNING)
    logging.basicConfig(
        level=level,
        stream=sys.stderr,
        format="[cjpy-mcp] %(levelname)s %(name)s: %(message)s",
    )


def _load_instructions() -> str:
    try:
        return _INSTRUCTIONS_FILE.read_text(encoding="utf-8")
    except OSError as exc:
        _LOGGER.warning("无法读取 MCP instructions: %s", exc)
        return "cjpy 金融数据查询工具。"


def _server_version() -> str:
    from cjpy._version import __version__

    return __version__


def create_server() -> "FastMCP":
    """创建已注册全部工具的 FastMCP 实例。"""
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:  # pragma: no cover
        raise ImportError("未安装 MCP 依赖，请执行 pip install 'cjpy[mcp]'") from exc

    # 延迟导入，确保基础安装仍可执行 cjpy-mcp --help/--version。
    from cjpy.mcp.prompts import register_all_prompts
    from cjpy.mcp.resources import register_api_resources
    from cjpy.mcp.tools import register_all_tools

    server = FastMCP(
        name="cjpy",
        instructions=_load_instructions(),
        log_level=_log_level_name(),
    )
    register_all_tools(server)
    register_api_resources(server)
    register_all_prompts(server)

    # mcp 1.x 的 FastMCP 构造函数没有 server version 参数，在适配层集中设置。
    inner = getattr(server, "_mcp_server", None)
    if inner is not None and hasattr(inner, "version"):
        inner.version = _server_version()
    return server


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="cjpy-mcp",
        description="通过 stdio 启动 cjpy FastMCP Server。",
    )
    parser.add_argument("--version", action="store_true", help="打印 cjpy 版本号并退出")
    parser.add_argument(
        "--check",
        action="store_true",
        help="检查 MCP 依赖、工具注册、token 和服务连通性",
    )
    return parser.parse_args(argv)


def _run_check() -> int:
    from cjpy import api as cj_api
    from cjpy.base import get_token

    print(f"cjpy version: {_server_version()}")
    print(f"Python: {sys.version.split()[0]} on {sys.platform}")
    try:
        server = create_server()
        registered = asyncio.run(server.list_tools())
        registered_prompts = asyncio.run(server.list_prompts())
    except ImportError as exc:
        print(f"MCP dependency: FAILED ({exc})")
        return 2
    except Exception as exc:  # noqa: BLE001
        print(f"MCP registration: FAILED ({exc.__class__.__name__}: {exc})")
        return 3

    print(f"MCP tools: {len(registered)}")
    for tool in registered:
        print(f"  - {tool.name}")
    print(f"MCP prompts: {len(registered_prompts)}")
    for prompt in registered_prompts:
        print(f"  - {prompt.name}")
    try:
        get_token()
    except Exception as exc:  # noqa: BLE001 - 自检需要输出分类而不是抛出堆栈
        print(f"token: FAILED ({exc.__class__.__name__}: {exc})")
        return 2
    print("token: configured")

    try:
        universes = cj_api.list_universes()
    except Exception as exc:  # noqa: BLE001 - 报告实际连通性
        print(f"service: FAILED ({exc.__class__.__name__}: {exc})")
        return 3
    print(f"service: reachable ({len(universes)} universes)")
    return 0


def main(argv: list[str] | None = None) -> int:
    """命令行入口。"""
    args = _parse_args(argv if argv is not None else sys.argv[1:])
    if args.version:
        print(_server_version())
        return 0

    _configure_utf8()
    _configure_logging()
    if args.check:
        return _run_check()

    try:
        server = create_server()
    except ImportError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    from cjpy.mcp.tools import ALL_TOOLS

    _LOGGER.info("启动 cjpy FastMCP stdio server，共 %d 个工具", len(ALL_TOOLS))
    server.run(transport="stdio")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
