# -*- coding: utf-8 -*-
"""注册与当前 cjpy 版本一致的本地 API 文档资源。"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from cjpy.introspection import describe_api

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register_api_resources(server: "FastMCP") -> None:
    """注册 API 目录资源和按函数名读取的文档资源模板。"""

    @server.resource(
        "cjpy://docs/api",
        name="cjpy_api_catalog",
        title="cjpy API 目录",
        description="当前安装版本的 cjpy Python 查询接口目录。",
        mime_type="application/json",
    )
    def api_catalog() -> dict[str, Any]:
        return describe_api()

    @server.resource(
        "cjpy://docs/api/{function}",
        name="cjpy_api_reference",
        title="cjpy API 函数文档",
        description="按 Python 函数名读取当前安装版本的结构化接口文档。",
        mime_type="application/json",
    )
    def api_reference(function: str) -> dict[str, Any]:
        return describe_api(function)


__all__ = ["register_api_resources"]
