# --*-- coding:utf-8 --*--
# @Time : 2026/4/20 16:29
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : api.py
# @Software : PyCharm

"""天软数据服务的高层查询接口。

本模块将代码列表、交易日、行情、服务端结构化数据表、因子和宏观数据等远端
能力封装为 Python 函数。除特别说明外，证券代码同时支持 Wind 格式
（如 ``000001.SZ``）和天软格式（如 ``SZ000001``），返回的表格数据使用
:class:`pandas.DataFrame`。

所有公开函数都接受仅限关键字参数 ``client``。不传时使用全局默认客户端；
需要自定义 token、服务地址、超时或证书校验时，可传入独立的
:class:`cjpy.base.CjClient` 实例。

高层接口只校验长期稳定的 Python 数据结构，并对常见日期和证券代码做规范化；
板块、字段、周期、复权方式、表名、因子及权限等动态业务规则由服务端判定。
网络和认证错误沿用 :mod:`cjpy.base` 的异常；服务端返回的数据不符合本模块声明
的列表、字典或表格契约时，抛出 :class:`CjAPIError`。
"""

import re
import threading
import warnings
import weakref
from typing import Any, TypeAlias

import pandas as pd
from cjpy.base import CjClient, CjError, get_default_client
from cjpy.utils import tscode
from ._version import __version__

TradingCycle: TypeAlias = str
MarketCycle: TypeAlias = str
Adjustment: TypeAlias = str


class CjAPIError(CjError):
    """服务端返回值不符合 cjpy 高层 API 契约。"""


_TINYSOFT_CODE_PATTERN = re.compile(r"^[A-Za-z]{2,}\d[A-Za-z0-9]*$")
_DATE_WITH_HYPHENS_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATE_COMPACT_PATTERN = re.compile(r"^\d{8}$")
_CODE_MAPPING_CACHE: weakref.WeakKeyDictionary[CjClient, dict[str, str]] = (
    weakref.WeakKeyDictionary()
)
_CODE_MAPPING_LOCK = threading.RLock()


def _resolve_client(client: CjClient | None) -> CjClient:
    return get_default_client() if client is None else client


def _require_text(value: Any, name: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name}参数必须是字符串")
    value = value.strip()
    if not value:
        raise ValueError(f"{name}参数不能为空")
    return value


def _clean_optional_text(value: Any, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{name}参数必须是字符串或 None")
    value = value.strip()
    return value or None


def _ensure_text_list(
    value: str | list[str],
    name: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, list):
        values = list(value)
    else:
        raise TypeError(f"{name}参数必须是字符串或字符串列表")

    if not values and not allow_empty:
        raise ValueError(f"{name}参数不能为空列表")

    normalized: list[str] = []
    for index, item in enumerate(values):
        if not isinstance(item, str):
            raise TypeError(f"{name}[{index}]必须是字符串")
        item = item.strip()
        if not item:
            raise ValueError(f"{name}[{index}]不能为空")
        normalized.append(item)
    return normalized


def _normalize_date(value: str, name: str, *, allow_all: bool = False) -> str:
    value = _require_text(value, name)
    if allow_all and value == "all":
        return value
    if _DATE_WITH_HYPHENS_PATTERN.fullmatch(value):
        return value.replace("-", "")
    return value


def _normalize_optional_date(value: Any, name: str) -> str | None:
    """规范化可选日期，并保留 ``None`` 表示未提供。"""
    value = _clean_optional_text(value, name)
    if value is None:
        return None
    return _normalize_date(value, name)


def _normalize_repo(repo: dict[str, str] | None) -> dict[str, str]:
    if repo is None:
        return {}
    if not isinstance(repo, dict):
        raise TypeError("repo参数必须是字符串到字符串的字典或 None")

    normalized: dict[str, str] = {}
    for name, expression in repo.items():
        normalized[_require_text(name, "repo中的因子名称")] = _require_text(
            expression, f"repo[{name!r}]"
        )
    return normalized


def _expect_string_list(
    result: Any,
    operation: str,
    *,
    none_as_empty: bool = False,
) -> list[str]:
    if result is None and none_as_empty:
        return []
    if not isinstance(result, (list, tuple)):
        raise CjAPIError(f"{operation}返回值应为字符串列表，实际为{type(result).__name__}")

    values: list[str] = []
    for index, item in enumerate(result):
        if not isinstance(item, str):
            raise CjAPIError(
                f"{operation}返回值第{index}项应为字符串，实际为{type(item).__name__}"
            )
        values.append(item)
    return values


def _expect_mapping(result: Any, operation: str) -> dict[str, str]:
    if not isinstance(result, dict):
        raise CjAPIError(f"{operation}返回值应为字典，实际为{type(result).__name__}")

    mapping: dict[str, str] = {}
    for key, value in result.items():
        if not isinstance(key, str) or not isinstance(value, str):
            raise CjAPIError(f"{operation}返回值的键和值都必须是字符串")
        mapping[key] = value
    return mapping


def _expect_dataframe(
    result: Any,
    operation: str,
    *,
    none_as_empty: bool = False,
    empty_columns: list[str] | None = None,
) -> pd.DataFrame:
    if result is None:
        if none_as_empty:
            return pd.DataFrame(columns=empty_columns)
        raise CjAPIError(f"{operation}未返回数据")
    if isinstance(result, str):
        raise CjAPIError(result)
    if isinstance(result, pd.DataFrame):
        return result.copy()

    try:
        if isinstance(result, list):
            return pd.DataFrame(result)
        if isinstance(result, dict):
            split_keys = {"data", "index", "columns", "dtype", "copy"}
            if "data" in result and set(result).issubset(split_keys):
                return pd.DataFrame(**result)
            try:
                return pd.DataFrame(result)
            except ValueError:
                return pd.DataFrame([result])
    except (TypeError, ValueError) as exc:
        raise CjAPIError(f"{operation}返回的表格数据无法解析：{exc}") from exc

    raise CjAPIError(
        f"{operation}返回值应为表格结构，实际为{type(result).__name__}"
    )


def _clear_code_mapping_cache() -> None:
    """清空代码映射缓存，仅供测试和进程内显式重置使用。"""
    with _CODE_MAPPING_LOCK:
        _CODE_MAPPING_CACHE.clear()


def _get_code_mappings(client: CjClient) -> dict[str, str]:
    with _CODE_MAPPING_LOCK:
        cached = _CODE_MAPPING_CACHE.get(client)
        if cached is not None:
            return dict(cached)
        return list_code_mappings(client=client)


def _normalize_code(code: str, *, client: CjClient) -> str:
    code = _require_text(code, "code")
    if _TINYSOFT_CODE_PATTERN.fullmatch(code):
        return code.upper()

    upper_code = code.upper()
    try:
        mappings = _get_code_mappings(client)
    except CjError:
        mappings = {}

    mapped = mappings.get(code) or mappings.get(upper_code)
    if mapped is not None:
        return mapped
    if code.count(".") == 1:
        return tscode(upper_code)
    return code


def _normalize_codes(code: str | list[str], *, client: CjClient) -> list[str]:
    return [
        _normalize_code(item, client=client)
        for item in _ensure_text_list(code, "code")
    ]

def _with_client_version(params: dict[str, Any]) -> dict[str, Any]:
    return {
        **params,
        "client_version": __version__,
    }

## ***********************取代码的接口***********************

def list_universes(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出服务端支持的证券板块（universe）。

    返回结果用于发现可传给 :func:`get_codes` 的 ``universe`` 值。板块的具体
    名称、标识和其他描述字段由服务端定义，可能随数据服务配置变化。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        板块定义表。每行代表一个可查询板块，具体列以服务端返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> universes = cjpy.list_universes()
        >>> print(universes.head())
    """
    client = _resolve_client(client)
    result = client.post_call("universe", _with_client_version({}))
    return _expect_dataframe(result, "list_universes")

def list_code_mappings(*, client: CjClient | None = None) -> dict[str, str]:
    """
    获取 Wind 代码到天软代码的映射关系。

    返回一个字典，其中键是 Wind 格式的证券代码，值是对应的天软格式证券
    代码。例如，键 ``"000001.SZ"`` 对应的值为 ``"SZ000001"``。
    映射所覆盖的证券类型由服务端定义，可能随数据服务配置变化。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        Wind 代码到天软代码的映射字典。键为 Wind 代码，值为天软代码。
        本次结果也会更新当前 ``client`` 对应的进程内代码映射缓存；返回字典
        是独立副本，调用方修改它不会污染缓存。

    Raises:
        CjAPIError: 返回值不是“字符串键到字符串值”的字典。

    Examples:
        >>> import cjpy
        >>> mappings = cjpy.list_code_mappings()
        >>> mappings["000001.SZ"]
        'SZ000001'
    """
    client = _resolve_client(client)
    result = client.post_call("code_mapping", _with_client_version({}))
    mapping = _expect_mapping(result, "list_code_mappings")
    with _CODE_MAPPING_LOCK:
        _CODE_MAPPING_CACHE[client] = dict(mapping)
    return dict(mapping)

def get_codes(universe: str, date: str | None = None, *, client: CjClient | None = None) -> list[str]:
    """
    获取指定板块在某个日期的证券代码列表。

    这是通用的代码列表接口。可先调用 :func:`list_universes` 查看支持的板块，
    再将其中的板块标识传给本函数。日期中的连字符会在请求前自动移除。

    Args:
        universe: 板块名称或标识，例如 ``"stock.a"`` 或 ``"fund"``；有效值
            以 :func:`list_universes` 的返回结果为准。
        date: 查询截面日期。常用格式为 ``"YYYYMMDD"`` 或
            ``"YYYY-MM-DD"``；后一种会规范化为前一种，其他非空字符串原样
            交给服务端。不传时使用本机当天日期。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        属于该板块的证券代码列表。代码格式由服务端返回结果决定。

    Raises:
        TypeError: ``universe`` 或 ``date`` 的 Python 类型不正确。
        ValueError: ``universe`` 或 ``date`` 是空字符串。
        CjAPIError: 服务端没有返回字符串列表。

    Examples:
        >>> import cjpy
        >>> codes = cjpy.get_codes("stock.a", "2026-04-24")
        >>> fund_codes = cjpy.get_codes("fund")
    """
    universe = _require_text(universe, "universe")
    if date is None:
        date = pd.to_datetime('today').strftime('%Y%m%d')
    else:
        date = _normalize_date(date, 'date')

    client = _resolve_client(client)
    codes = client.post_call("codes", _with_client_version({'universe': universe, 'EndT': date}))

    if codes is None:
        raise CjAPIError(f'不支持的板块标识：{universe}')

    return _expect_string_list(codes, "get_codes")

def get_stocks(date: str | None = None, *, client: CjClient | None = None) -> list[str]:
    """
    获取指定日期的全 A 股代码列表。

    日期中的连字符会在请求前自动移除。传入 ``"all"`` 时，请求服务端维护的
    历史全部股票代码，而不是某一交易日的截面。

    Args:
        date: 查询日期，支持 ``"YYYYMMDD"``、``"YYYY-MM-DD"`` 或
            ``"all"``。不传时使用本机当天日期。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        股票代码列表。代码格式由服务端返回结果决定。

    Raises:
        TypeError: ``date`` 既不是字符串也不是 ``None``。
        ValueError: ``date`` 是空字符串。
        CjAPIError: 服务端没有返回字符串列表。

    Examples:
        >>> import cjpy
        >>> cjpy.get_stocks()
        >>> cjpy.get_stocks("20260424")
        >>> cjpy.get_stocks("all")
    """
    if date is None:
        date = pd.to_datetime('today').strftime('%Y%m%d')
    else:
        date = _normalize_date(date, 'date', allow_all=True)

    client = _resolve_client(client)
    stocks = client.post_call("stocks", [date])

    return _expect_string_list(stocks, "get_stocks")

def get_funds(date: str | None = None, *, client: CjClient | None = None) -> list[str]:
    """
    获取指定日期的基金代码列表。

    本函数是 :func:`get_codes` 的便捷封装，内部固定使用 ``universe="fund"``。
    日期中的连字符会在请求前自动移除。

    Args:
        date: 查询截面日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
            不传时使用本机当天日期。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        基金代码列表。代码格式由服务端返回结果决定。

    Raises:
        TypeError: ``date`` 既不是字符串也不是 ``None``。
        ValueError: ``date`` 是空字符串。
        CjAPIError: 服务端没有返回基金代码字符串列表。

    Examples:
        >>> import cjpy
        >>> funds = cjpy.get_funds("2026-04-24")
    """
    client = _resolve_client(client)
    return get_codes(universe='fund', date=date, client=client)

def get_index_constituents(code: str, date: str | None = None, *, client: CjClient | None = None) -> list[str]:
    """
    获取指定指数在某个日期的成分证券代码。

    指数代码会统一转换为天软格式，日期中的连字符会被移除。服务端通常维护
    上证、中证、深证、巨潮和申万等系列的非综合指数成分；某个指数是否可用
    仍以服务端实际数据为准。

    Args:
        code: 指数代码，支持 Wind 格式（如 ``"000300.SH"``）或天软格式
            （如 ``"SH000300"``）。
        date: 成分股截面日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
            不传时使用本机当天日期。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        指数成分证券代码列表。代码格式由服务端返回结果决定。

    Raises:
        TypeError: ``code`` 或 ``date`` 的 Python 类型不正确。
        ValueError: ``code`` 或 ``date`` 是空字符串。
        CjAPIError: 服务端没有返回成分证券字符串列表。

    Examples:
        >>> import cjpy
        >>> members = cjpy.get_index_constituents("000300.SH", "2026-04-24")
    """
    client = _resolve_client(client)
    code = _normalize_code(code, client=client)
    if date is None:
        date = pd.to_datetime('today').strftime('%Y%m%d')
    else:
        date = _normalize_date(date, 'date')

    constituents = client.post_call("index_samples", _with_client_version({'code': code, 'EndT': date}))

    return _expect_string_list(constituents, "get_index_constituents")

# ***********************取交易日的接口***********************
def get_trading_days(
    start: str,
    end: str,
    cycle: TradingCycle | None = None,
    code: str | None = None,
    *,
    client: CjClient | None = None
) -> list[str]:
    """
    获取指定日期区间和周期的交易日期序列。

    函数让服务端按照 ``code`` 和 ``cycle`` 生成日期序列。服务端返回天软
    数值日期时会转换为 ``YYYYMMDD``；如果返回日期字符串，则保留服务端格式，
    仅把标准 ``YYYY-MM-DD`` 转成 ``YYYYMMDD``。不指定证券时以上证指数
    ``SH000001`` 作为交易日历基准。

    Args:
        start: 区间开始日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
        end: 区间结束日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
        cycle: 取样周期。不传时为 ``"D"``。当前常用值包括 ``"D"``（日）、
            ``"W"``（周）、``"M"``（月）、``"Q"``（季度）、``"H"``（半年）
            和 ``"Y"``（年）；客户端接受任意非空字符串，最终支持范围以服务端
            为准。
        code: 用于确定交易日历的证券代码，支持 Wind 格式或天软格式。不传时
            使用 ``"SH000001"``。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        日期字符串列表。标准服务端响应会得到 ``YYYYMMDD``；顺序由服务端决定。

    Raises:
        TypeError: ``start``、``end``、``cycle`` 或 ``code`` 的类型不正确。
        ValueError: 必填字符串为空。
        CjAPIError: 服务端返回值不是日期列表，或其中的数值日期无法转换。

    Examples:
        >>> import cjpy
        >>> days = cjpy.get_trading_days("20260401", "20260424")
        >>> month_ends = cjpy.get_trading_days(
        ...     "20260101", "20261231", cycle="M", code="000001.SZ"
        ... )
    """
    client = _resolve_client(client)
    code = _normalize_code(code or 'SH000001', client=client)
    cycle = _require_text(cycle or 'D', 'cycle')
    start = _normalize_date(start, 'start')
    end = _normalize_date(end, 'end')
    days = client.post_call("trading_days", _with_client_version({'start_date': start, 'end_date': end, 'cycle': cycle, 'code': code}))
    if days is None:
        return []
    if not isinstance(days, (list, tuple)):
        raise CjAPIError(
            f"get_trading_days返回值应为日期列表，实际为{type(days).__name__}"
        )

    if all(isinstance(day, str) for day in days):
        normalized_days = [_normalize_date(day, "服务端日期") for day in days]
    else:
        try:
            normalized_days = (
                pd.to_datetime(days, unit="D", origin="1899-12-30")
                .strftime('%Y%m%d')
                .tolist()
            )
        except (TypeError, ValueError, OverflowError) as exc:
            raise CjAPIError(f"get_trading_days返回的日期无法解析：{exc}") from exc

    if _DATE_COMPACT_PATTERN.fullmatch(start) and _DATE_COMPACT_PATTERN.fullmatch(end):
        return [day for day in normalized_days if start <= day <= end]
    return normalized_days

# ***********************取行情数据的接口***********************
def list_market_fields(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出行情接口支持的字段。

    可用本函数发现 :func:`get_market_data` 的 ``fields`` 参数可填写哪些字段。
    字段名称、含义和其他元数据均由服务端定义。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        行情字段定义表。每行代表一个可查询字段，具体列以服务端返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> fields = cjpy.list_market_fields()
        >>> print(fields.head())
    """
    client = _resolve_client(client)
    results = client.post_call("markettable_columns", _with_client_version({}))
    return _expect_dataframe(results, "list_market_fields")

def get_market_data(
    code: str,
    start: str,
    end: str,
    cycle: MarketCycle | None = None,
    rate: Adjustment | None = None,
    fields: str | list[str] | None = None,
    *,
    client: CjClient | None = None,
) -> pd.DataFrame:
    """
    获取单只证券在指定日期区间内的 K 线行情。

    证券代码会统一转换为天软格式，日期中的连字符会被移除。日期区间、周期、
    复权方式和字段列表会发送给服务端，由服务端生成最终的数据列和记录。

    Args:
        code: 证券代码，支持 Wind 格式（如 ``"000001.SZ"``）或天软格式
            （如 ``"SZ000001"``）。本接口一次只查询一只证券。
        start: 区间开始日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
        end: 区间结束日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``。
        cycle: K 线周期，不传时为 ``"day"``。当前常用值包括 ``"1m"``、
            ``"5m"``、``"15m"``、``"30m"``、``"60m"``、``"120m"`` 和
            ``"day"``。客户端接受任意非空字符串，最终支持范围以服务端为准。
        rate: 复权方式，不传时为 ``"不复权"``。当前常用值包括 ``"不复权"``、
            ``"前复权"`` 和 ``"后复权"``；最终支持范围以服务端为准。
        fields: 要返回的字段名或字段名列表。可先调用 :func:`list_market_fields`
            查看支持的字段。不传时向服务端发送空列表，表示获取默认的全部字段。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        行情数据表。行通常对应一个交易时点，具体列由 ``fields`` 和服务端定义。

    Raises:
        TypeError: 参数的 Python 类型不正确，或 ``fields`` 列表包含非字符串。
        ValueError: 必填字符串为空，或 ``fields`` 包含空字符串。
        CjAPIError: 服务端没有返回可解析的行情表格。

    Notes:
        客户端不会比较 ``start`` 与 ``end``，也不会维护周期和复权方式白名单；
        这些业务规则由服务端统一校验。因此服务端增加新取值时通常无需升级 cjpy。

    Examples:
        >>> import cjpy
        >>> df = cjpy.get_market_data(
        ...     "000001.SZ",
        ...     "20260401",
        ...     "20260424",
        ...     cycle="5m",
        ...     rate="前复权",
        ...     fields=["date", "time", "open", "high", "low", "close"],
        ... )
        >>> df.head()
    """
    
    client = _resolve_client(client)
    code = _normalize_code(code, client=client)
    start = _normalize_date(start, 'start')
    end = _normalize_date(end, 'end')
    cycle = _require_text(cycle or 'day', 'cycle')
    rate = _require_text(rate or '不复权', 'rate')
    normalized_fields = (
        [] if fields is None else _ensure_text_list(fields, 'fields', allow_empty=True)
    )

    result = client.post_call("highfrequency", 
                              _with_client_version({'code': code, 'start_date': start, 'end_date': end, 'cycle': cycle, 'rate': rate, 'fields': normalized_fields}))

    return _expect_dataframe(result, "get_market_data")

# ***********************取表格数据的接口***********************

def get_supported_tables(*, client: CjClient | None = None) -> list[str]:
    """
    获取服务端支持的表名列表（已弃用）。

    .. deprecated:: 0.2.1
        请改用 :func:`list_tables`。该接口仅为向后兼容保留，
        并计划在 ``cjpy 1.0.0`` 中删除。

    本函数调用 :func:`list_tables`，并从其返回表的 ``"表名"`` 列提取字符串
    列表。新代码需要表的完整元数据时应直接使用 :func:`list_tables`。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        服务端支持的表名列表。

    Warns:
        DeprecationWarning: 每次调用都会发出弃用警告。

    Examples:
        >>> import cjpy
        >>> table_names = cjpy.get_supported_tables()
    """
    warnings.warn(
        "get_supported_tables() 已弃用，请使用 list_tables()；"
        "该接口计划在 cjpy 1.0.0 中删除。",
        DeprecationWarning,
        stacklevel=2,
    )
    return list_tables(client=client)['表名'].tolist()

def list_tables(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出 :func:`get_table_data` 支持的服务端结构化数据表。

    该接口用于发现 :func:`list_table_fields` 和 :func:`get_table_data` 可使用的
    ``table_name``。表格范围由服务端目录决定，可能包括证券基本信息、财务、
    基本面、股东与股本、基金、债券、宏观及其他按表组织的数据，不限于某一类
    业务数据。与旧接口 :func:`get_supported_tables` 不同，本函数保留服务端
    返回的完整表级元数据。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        数据表定义表，通常包含 ``"表名"`` 列；其他列以服务端返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> tables = cjpy.list_tables()
        >>> table_names = tables["表名"].tolist()
    """
    client = _resolve_client(client)
    result = client.post_call("table_infor", _with_client_version({}))
    return _expect_dataframe(result, "list_tables")

def list_table_fields(table_name: str, *, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出指定数据表支持的字段。

    可先调用 :func:`list_tables` 获取有效表名，再用本函数发现
    :func:`get_table_data` 的 ``fields`` 参数可使用哪些字段。

    Args:
        table_name: 数据表名称，必须是服务端支持的表名。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        字段定义表。每行代表一个字段，具体元数据列以服务端返回为准。

    Raises:
        TypeError: ``table_name`` 不是字符串。
        ValueError: ``table_name`` 是空字符串。
        CjAPIError: 服务端返回错误文本或不可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> fields = cjpy.list_table_fields("股本结构")
        >>> print(fields.head())
    """
    table_name = _require_text(table_name, "table_name")
    client = _resolve_client(client)
    results = client.post_call("table_fields", _with_client_version({'table_name': table_name}))
    return _expect_dataframe(results, "list_table_fields")

def get_table_data(
    code: str | list[str],
    table_name: str,
    fields: str | list[str] | None = None, 
    start: str | None = None,
    end: str | None = None,
    *, client: CjClient | None = None
) -> pd.DataFrame:
    """
    按代码查询指定的服务端结构化数据表。

    本函数是服务端按表组织数据的通用查询入口，不仅用于财务和基本面数据。
    当前可查询的表格及其元数据必须通过 :func:`list_tables` 获取，指定表的
    字段必须通过 :func:`list_table_fields` 获取，不应根据固定类别或历史版本
    猜测表名和字段。

    ``code`` 会被转换成天软格式的代码列表。不同表要求不同类型的代码：股票表
    传股票代码，基金表传基金代码，债券表传债券代码；需要通过该通用表接口读取
    宏观经济表（以“宏观_”开头的表）时，通常使用 ``"HG000001"``。具体要求以
    :func:`list_tables` 返回的表级元数据为准。

    ``start`` 和 ``end`` 是可选的服务端时间范围条件，但并非所有表都具有可用于
    筛选的时间维度。例如 ``"股票基本信息"`` 是静态表，传入这两个参数不会改变
    其查询范围。对于支持时间筛选的表，服务端可能在表的多个日期字段中指定一个
    字段作为筛选依据；应先查看 :func:`list_tables` 返回的对应表元数据，确认
    ``start`` 和 ``end`` 实际限定哪个日期字段，而不能仅根据结果表中的日期列名
    推断。

    Args:
        code: 单个证券代码或证券代码列表，支持 Wind 格式和天软格式。
        table_name: 要查询的服务端结构化数据表名称。有效值及表格范围完全以
            :func:`list_tables` 当前返回结果为准。
        fields: 要返回的字段名或字段名列表。不传时向服务端发送空列表，表示
            获取该表的全部默认字段；也可以传入 ``"*"``，具体含义由服务端解释。
        start: 可选的开始日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``；
            后一种会规范化为服务端要求的 ``"YYYYMMDD"``。仅对支持时间筛选
            的表生效；筛选所依据的日期字段应通过 :func:`list_tables` 查看，
            静态表会忽略该条件。不传或传入空白字符串时不限定开始日期。
        end: 可选的结束日期，支持格式和规范化规则与 ``start`` 相同。
            不传或传入空白字符串时不限定结束日期。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        查询结果表。字段、日期列和排序方式由目标表及服务端返回结果决定。

    Raises:
        TypeError: 参数的 Python 类型不正确，或代码、字段列表中包含非字符串。
        ValueError: 必填字符串或列表为空，或字符串列表包含空值。
        CjAPIError: 服务端没有返回可解析的查询结果表格。

    Notes:
        ``start`` 和 ``end`` 是目标表定义的时间筛选条件，不是对返回
        :class:`pandas.DataFrame` 中任意日期列执行的通用过滤：

        - 静态表没有适用的日期维度，例如 ``"股票基本信息"``，因此会忽略这两个
          参数。
        - 有日期概念的表可能同时包含公布日、报告期、截止日等多个日期字段，实际
          用于限定查询范围的字段以 :func:`list_tables` 返回的表级元数据为准。
        - 如果需要按照其他日期字段筛选，应在取得结果后自行对相应列做二次过滤。

    Examples:
        >>> import cjpy
        >>> tables = cjpy.list_tables()
        >>> print(tables.loc[tables["表名"] == "股本结构"])
        >>> df = cjpy.get_table_data(
        ...     ["000001.SZ", "000002.SZ"],
        ...     "股本结构",
        ...     fields=["截止日", "总股本"],
        ...     start="20240101",
        ...     end="20241231",
        ... )
        >>> basic = cjpy.get_table_data(
        ...     "000001.SZ",
        ...     "股票基本信息",
        ...     start="20240101",
        ...     end="20241231",
        ... )  # 静态表会忽略 start 和 end
    """
    client = _resolve_client(client)
    codes = _normalize_codes(code, client=client)
    table_name = _require_text(table_name, "table_name")
    normalized_fields = (
        [] if fields is None else _ensure_text_list(fields, 'fields', allow_empty=True)
    )
    start = _normalize_optional_date(start, "start")
    end = _normalize_optional_date(end, "end")
    result = client.post_call("table", _with_client_version({
        'code': codes,
        'table_name': table_name,
        'fields': normalized_fields,
        'begT': start,
        'EndT': end
    }))
    if result is None:
        raise CjAPIError(f'服务端未返回表数据：{table_name}')
    return _expect_dataframe(result, "get_table_data")

# ***********************取宏观数据的接口***********************
def list_macro_tables(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出服务端支持的宏观数据表。

    返回结果用于了解宏观指标所属的数据表，并辅助构造
    :func:`get_macro_data` 的 ``indicator`` 参数。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        宏观数据表定义。表名、表 ID 和其他元数据列以服务端返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> tables = cjpy.list_macro_tables()
        >>> print(tables.head())
    """
    client = _resolve_client(client)
    results =  client.post_call("macro_table", _with_client_version({}))
    return _expect_dataframe(results, "list_macro_tables")

def list_macro_indicators(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出服务端支持的宏观指标。

    返回结果用于发现 :func:`get_macro_data` 可查询的指标名称、指标 ID 及其
    所属表。名称重复时，应结合表名或表 ID 唯一确定指标。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        宏观指标定义表。通常包含指标名称、指标 ID、表名和表 ID 等列，具体
        结构以服务端返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> indicators = cjpy.list_macro_indicators()
        >>> print(indicators.head())
    """
    client = _resolve_client(client)
    results =  client.post_call("macro_indicator", _with_client_version({}))
    return _expect_dataframe(results, "list_macro_indicators")

def get_macro_data(
    indicator: str,
    start: str | None = None,
    end: str | None = None,
    *, client: CjClient | None = None,
) -> pd.DataFrame:
    """
    获取指定宏观指标的时间序列数据。

    可先调用 :func:`list_macro_indicators` 查看指标名称、指标 ID 及所属表。
    ``indicator`` 会原样传给服务端解析。``start`` 和 ``end`` 支持
    ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``；后一种会在请求前规范化为服务端
    要求的 ``"YYYYMMDD"``。本函数不检查日期真实性或起止顺序。

    Args:
        indicator: 指标定位字符串。支持 ``"指标名称@表名"`` 或
            ``"指标ID@表ID"`` 等服务端可识别的格式。建议在指标名称不唯一时
            显式指定所属表。
        start: 可选的开始日期，支持 ``"YYYYMMDD"`` 或 ``"YYYY-MM-DD"``；
            后一种会规范化为 ``"YYYYMMDD"``。不传或传入空白字符串时由
            服务端决定查询起点。
        end: 可选的结束日期，支持格式和规范化规则与 ``start`` 相同。
            不传或传入空白字符串时由服务端决定查询终点。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        宏观指标时间序列表，具体日期列、数值列和其他字段由服务端定义。

    Raises:
        TypeError: ``indicator``、``start`` 或 ``end`` 的类型不正确。
        ValueError: ``indicator`` 是空字符串。
        CjAPIError: 服务端返回错误文本或不可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> indicators = cjpy.list_macro_indicators()
        >>> data = cjpy.get_macro_data(
        ...     "居民消费价格指数@价格指数",
        ...     start="20200101",
        ...     end="20261231",
        ... )
    """
    indicator = _require_text(indicator, "indicator")
    start = _normalize_optional_date(start, "start")
    end = _normalize_optional_date(end, "end")
    client = _resolve_client(client)
    results = client.post_call("macro_data", _with_client_version({
        'indicator': indicator,
        'begT': start,
        'EndT': end
    }))
    return _expect_dataframe(results, "get_macro_data")

# ***********************取因子数据的接口***********************
def get_factor_repo(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    获取服务端预定义因子列表（已弃用）。

    .. deprecated:: 0.2.1
        请改用 :func:`list_factors`。该接口仅为向后兼容保留，
        并计划在 ``cjpy 1.0.0`` 中删除。

    本函数仅发出弃用警告，然后将 ``client`` 原样传给 :func:`list_factors`；
    返回内容与 :func:`list_factors` 完全一致。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        服务端预定义的因子定义表。

    Warns:
        DeprecationWarning: 每次调用都会发出弃用警告。

    Examples:
        >>> import cjpy
        >>> factors = cjpy.get_factor_repo()
    """
    warnings.warn(
        "get_factor_repo() 已弃用，请使用 list_factors()；"
        "该接口计划在 cjpy 1.0.0 中删除。",
        DeprecationWarning,
        stacklevel=2,
    )
    return list_factors(client=client)

def list_factors(*, client: CjClient | None = None) -> pd.DataFrame:
    """
    列出服务端预定义的因子。

    返回结果用于发现 :func:`get_factor_data` 的 ``factors`` 参数可使用哪些
    因子名称。这里只列出服务端预定义因子；调用 :func:`get_factor_data` 时还可
    通过 ``repo`` 临时增加自定义因子。

    Args:
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        因子定义表。每行代表一个预定义因子，名称、公式或说明等具体列以服务端
        返回为准。

    Raises:
        CjAPIError: 服务端没有返回可解析的表格结构。

    Examples:
        >>> import cjpy
        >>> factors = cjpy.list_factors()
        >>> print(factors.head())
    """
    client = _resolve_client(client)
    results = client.post_call("list_factors", _with_client_version({}))
    return _expect_dataframe(results, "list_factors")

def get_factor_data(
    code: str | list[str],
    date: str | list[str],
    factors: str | list[str],
    repo: dict[str, str] | None = None,
    *, client: CjClient | None = None,
) -> pd.DataFrame:
    """
    获取一只或多只证券在指定截面日期的因子值。

    证券代码会统一转换为天软格式；单个代码、日期或因子名称会自动包装成列表。
    日期字符串中的连字符会被移除。预定义因子可通过 :func:`list_factors`
    查询，也可以通过 ``repo`` 为本次请求提供自定义天软表达式。

    Args:
        code: 单个证券代码或证券代码列表，支持 Wind 格式（如
            ``"000001.SZ"``）和天软格式（如 ``"SZ000001"``）。
        date: 单个截面日期或日期列表。日期支持 ``"YYYYMMDD"`` 或
            ``"YYYY-MM-DD"``；列表中的每个元素都必须是字符串。
        factors: 单个因子名称或因子名称列表。预定义因子名称应来自
            :func:`list_factors`；自定义因子名称必须存在于 ``repo`` 中。
        repo: 本次请求使用的自定义因子库。键是 ``factors`` 中引用的因子名称，
            值是相应的天软公式字符串。不传时使用空字典，即只查询预定义因子。
        client: 用于发起请求的客户端。不传时使用默认客户端。

    Returns:
        因子数据表。通常包含 ``"截止日"``、``"代码"``、``"名称"`` 以及
        所请求的因子列。服务端返回 ``None`` 时返回只有这些列、没有数据行的
        空表，而不是返回 ``None``。

    Raises:
        TypeError: ``code``、``date``、``factors`` 或 ``repo`` 的 Python 结构
            不正确，或其列表、字典中包含非字符串。
        ValueError: 必填字符串或列表为空，或列表、``repo`` 中包含空字符串。
        CjAPIError: 服务端返回了无法解析的表格结构。

    Notes:
        查询规模约等于“代码数 × 日期数 × 因子数”。大规模请求可能耗时较长，
        建议按代码或日期分批调用。

    Examples:
        >>> import cjpy
        >>> df = cjpy.get_factor_data(
        ...     code=["000001.SZ", "000002.SZ"],
        ...     date=["20260331"],
        ...     factors=["收盘价"],
        ... )
        >>> custom = cjpy.get_factor_data(
        ...     code="SZ000001",
        ...     date="2026-03-31",
        ...     factors="振幅",
        ...     repo={"振幅": "(high()-low())/sys_prevclose()"},
        ... )
    """
    client = _resolve_client(client)
    codes = _normalize_codes(code, client=client)
    dates = [
        _normalize_date(item, "date")
        for item in _ensure_text_list(date, "date")
    ]
    normalized_factors = _ensure_text_list(factors, "factors")
    normalized_repo = _normalize_repo(repo)
    results = client.post_call("factor_data", _with_client_version({
        'codes': codes,
        'dates': dates,
        'factors': normalized_factors,
        'repo': normalized_repo
    }))
    return _expect_dataframe(
        results,
        "get_factor_data",
        none_as_empty=True,
        empty_columns=['截止日', '代码', '名称'] + normalized_factors,
    )


__all__ = [
    "CjAPIError",
    "TradingCycle",
    "MarketCycle",
    "Adjustment",
    "list_universes",
    "list_code_mappings",
    "get_codes",
    "get_stocks",
    "get_funds",
    "get_index_constituents",
    "get_trading_days",
    "list_market_fields",
    "get_market_data",
    "get_supported_tables",
    "list_tables",
    "list_table_fields",
    "get_table_data",
    "list_macro_tables",
    "list_macro_indicators",
    "get_macro_data",
    "get_factor_repo",
    "list_factors",
    "get_factor_data",
]
