# -*- coding: utf-8 -*-
# @Time : 2026/4/27 14:12
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : research.py
# @Software : PyCharm

import pandas as pd
from cjpy.api import get_factor_data, get_trading_days
from cjpy.utils import tscode


class DataSource:
    def __init__(self):
        pass

    def get_price_data(self, codes, d0, d1):
        """
        从Wind数据库中获取指定证券代码在指定日期范围内的收盘价数据。
        :param codes: 证券代码列表。
        :param d0: 起始日期，格式为YYYYMMDD。
        :param d1: 结束日期，格式为YYYYMMDD。
        :return: 返回一个DataFrame，列索引为股票代码，行索引为日期，值为价格。
        """
        dates = get_trading_days(start=d0, end=d1, cycle='D')
        code_alias = {tscode(code): code for code in codes if code != 'CASH'}
        return (
            get_factor_data(code=list(set(codes) - {'CASH'}), date=dates, factors=['收盘价','复权因子'])
            .assign(收盘价=lambda df: df['收盘价'] * df['复权因子'])
            .set_index(['截止日', '代码'])['收盘价']
            .unstack().sort_index()
            .rename(columns=code_alias)
            .reindex(columns=codes)
        )


class Backtest:
    def __init__(self, db=None):
        """
        初始化Backtest类，设置默认数据源
        :param db:
        """
        if db is None:
            self.db = DataSource()
        else:
            self.db = db

    def run(self, port, start_date=None, end_date=None):
        """
        回测函数，根据组合权重数据计算每个组合的净值曲线。
        :param port: 包含组合权重数据的DataFrame，必须包含以下列：
                     - '日期': 调仓日期
                     - '代码': 证券代码
                     - '权重': 每个证券在组合中的权重
                     - '组合名称': 组合的名称（可选）
        :param start_date: 回测开始日期，格式为YYYYMMDD。如果为None，则默认为组合权重数据中的最早日期。
        :param end_date: 回测结束日期，格式为YYYYMMDD。如果为None，则默认为组合权重数据中的最晚日期，此时最后一期调仓没有作用
        :return: 返回一个DataFrame，索引为日期，列为组合名称，值为对应的净值。
        """

        # 回测区间默认值
        if start_date is None:
            start_date = port['日期'].min()
        if end_date is None:
            end_date = port['日期'].max()

        # 截取回测区间范围内的权重数据
        port = port[(port['日期'] >= start_date) & (port['日期'] <= end_date)].copy()

        # 如果没有提供“组合名称”列，表明只有1个组合，添加默认的组合名称：策略
        if '组合名称' not in port:
            port['组合名称'] = '策略'

        # 现金仓位：现金代码CASH
        port = pd.concat([
            port,
            (1 - port.groupby(by=['组合名称', '日期'])['权重'].sum()).reset_index().assign(代码='CASH')
        ])

        # 调仓日期+截止日
        dates = port['日期'].drop_duplicates().sort_values().tolist()
        if end_date not in dates: dates.append(end_date)

        # 组合名称
        pnames = port['组合名称'].drop_duplicates().sort_values().tolist()

        # 初始净值
        latest = pd.Series({pname: 1 for pname in pnames})

        net_values = []
        N = len(dates)
        for i in range(N - 1):
            d0 = dates[i]
            d1 = dates[i + 1]

            print(d0, d1)

            # 调仓日每个组合的持仓明细
            df = port.query(f'日期=="{d0}"')

            # 证券池：调仓日所有组合目标持仓证券的并集
            codes = df['代码'].drop_duplicates().tolist()

            # 区间每日收盘价
            cdata = self.db.get_price_data(codes=codes, d0=d0, d1=d1).ffill()

            # 区间收盘行情净值化：初值为1
            # 这一步，cdata中没有的代码，都会视为现金（例如CASH）
            netv = (cdata / cdata.iloc[0]).fillna(1)

            # 区间组合净值
            netv = (
                netv
                .mul(df.set_index(['组合名称', '代码'])['权重'], level=1)  # 个股净值乘以权重
                .T.groupby(level=0).sum().T  # 按组合名称分组求和，得到每个组合的净值
                .mul(latest)  # 乘以上期末最新净值
            )

            # 更新组合最新净值
            if i + 1 < N - 1:
                latest = netv.loc[d1]
                netv = netv.drop(index=[d1])
            # 记录区间净值
            net_values.append(netv)

        # 汇总每个区间的结果，返回
        return pd.concat(net_values)

