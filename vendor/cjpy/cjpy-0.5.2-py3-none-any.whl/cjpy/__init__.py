# --*-- coding:utf-8 --*--
# @Time : 2026/4/20 16:29
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : __init__.py
# @Software : PyCharm

"""
cjpy: Tinysoft 市场数据与订阅接口的 Python 客户端。

该包对外暴露三类主要能力：

1. 同步查询接口
   用于获取股票、基金、交易日、行情、表格数据和因子数据等。

2. 认证与客户端管理
   用于设置 token、清除 token，或显式创建和注入 ``CjClient``。

3. 实时订阅接口
   用于启动后台订阅线程，并通过 ``Subscription`` 对象持续消费事件。

最常见的使用方式：

    >>> import cjpy
    >>> cjpy.set_token("your-token")
    >>> cjpy.get_stocks()
    >>> df = cjpy.get_market_data("000001.SZ", "20260401", "20260424")
    >>> sub = cjpy.subscribe(ids=["SZ000001"], fields=["price"])
    >>> event = sub.get(timeout=1)
    >>> sub.stop()

常用公开接口：

- ``set_token`` / ``clear_token``
- ``get_stocks`` / ``get_funds`` / ``get_trading_days``
- ``get_market_data`` / ``get_table_data`` / ``list_tables``
- ``get_factor_data`` / ``list_factors``
- ``subscribe`` / ``Subscription``

更多帮助可通过以下方式查看：

    >>> cjpy.describe_api("get_market_data")
    >>> help(cjpy.get_market_data)
    >>> help(cjpy.subscribe)
    >>> help(cjpy.Subscription)
"""

from ._version import __version__
from .api import (
    CjAPIError,
    get_codes,
    get_factor_data,
    get_factor_repo,
    get_funds,
    get_index_constituents,
    get_macro_data,
    get_market_data,
    get_stocks,
    get_supported_tables,
    get_table_data,
    get_trading_days,
    list_code_mappings,
    list_market_fields,
    list_table_fields,
    list_factors,
    list_macro_indicators,
    list_macro_tables,
    list_tables,
    list_universes,
)
from .base import (
    CjClient,
    CjConfigError,
    CjError,
    CjRequestError,
    clear_token,
    set_token,
)
from .introspection import describe_api
from .sub import Subscription, subscribe

__all__ = [
    "__version__",
    "CjClient",
    "CjError",
    "CjConfigError",
    "CjRequestError",
    "CjAPIError",
    "Subscription",
    "subscribe",
    "set_token",
    "clear_token",
    "describe_api",
    "list_universes",
    "list_code_mappings",
    "get_codes",
    "get_stocks",
    "get_funds",
    "get_index_constituents",
    "get_trading_days",
    "list_market_fields",
    "get_market_data",
    "list_tables",
    "list_table_fields",
    "get_table_data",
    "get_supported_tables",
    "list_factors",
    "get_factor_data",
    "get_factor_repo",
    "list_macro_tables",
    "list_macro_indicators",
    "get_macro_data",
]
