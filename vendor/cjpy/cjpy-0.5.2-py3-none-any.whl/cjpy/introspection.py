# -*- coding: utf-8 -*-
"""从当前安装版本的函数签名和 docstring 生成结构化 API 文档。"""

from __future__ import annotations

import inspect
import re
from collections.abc import Callable
from typing import Any

from cjpy._version import __version__

_SECTION_PATTERN = re.compile(r"^([A-Za-z][A-Za-z ]*):\s*$")
_NAMED_ITEM_PATTERN = re.compile(
    r"^\s*(\*{0,2}[A-Za-z_]\w*)(?:\s*\([^)]*\))?:\s*(.*)$"
)
_RELATED_FUNCTION_PATTERN = re.compile(r":func:`~?([^`]+)`")


def _api_functions() -> dict[str, Callable[..., Any]]:
    """返回 ``cjpy.api`` 中当前可公开调用的函数。"""
    from cjpy import api as api_module

    return {
        name: function
        for name in api_module.__all__
        if inspect.isfunction(function := getattr(api_module, name, None))
        and function.__module__ == api_module.__name__
    }


def _format_annotation(annotation: Any) -> str:
    if annotation is inspect.Signature.empty:
        return ""
    return inspect.formatannotation(annotation)


def _split_docstring(docstring: str) -> tuple[str, dict[str, str]]:
    """把 Google 风格 docstring 拆分为说明正文和命名章节。"""
    lines = inspect.cleandoc(docstring).splitlines()
    description_lines: list[str] = []
    sections: dict[str, list[str]] = {}
    current_section: str | None = None

    for line in lines:
        match = _SECTION_PATTERN.match(line)
        if match:
            current_section = match.group(1)
            sections.setdefault(current_section, [])
            continue

        if current_section is None:
            description_lines.append(line)
        else:
            sections[current_section].append(line)

    description = "\n".join(description_lines).strip()
    return description, {
        name: "\n".join(content).strip()
        for name, content in sections.items()
    }


def _summary(description: str) -> str:
    first_paragraph = description.split("\n\n", 1)[0]
    return " ".join(line.strip() for line in first_paragraph.splitlines()).strip()


def _parse_named_items(section: str) -> dict[str, str]:
    """解析 ``Args`` 和 ``Raises`` 中的名称及其多行说明。"""
    items: dict[str, list[str]] = {}
    current_name: str | None = None

    for line in section.splitlines():
        match = _NAMED_ITEM_PATTERN.match(line)
        if match:
            current_name = match.group(1)
            items[current_name] = [match.group(2).strip()]
        elif current_name is not None and line.strip():
            items[current_name].append(line.strip())

    return {
        name: " ".join(part for part in parts if part).strip()
        for name, parts in items.items()
    }


def _parameter_docs(function: Callable[..., Any], args_section: str) -> list[dict[str, Any]]:
    descriptions = _parse_named_items(args_section)
    parameters: list[dict[str, Any]] = []

    for parameter in inspect.signature(function).parameters.values():
        item: dict[str, Any] = {
            "name": parameter.name,
            "annotation": _format_annotation(parameter.annotation),
            "kind": parameter.kind.name.lower(),
            "required": parameter.default is inspect.Parameter.empty,
            "description": descriptions.get(parameter.name, ""),
        }
        if parameter.default is not inspect.Parameter.empty:
            item["default"] = parameter.default
        parameters.append(item)

    return parameters


def _resolve_function_name(function: str) -> str:
    name = function.strip()
    if name.startswith("cjpy."):
        name = name.removeprefix("cjpy.")
    return name


def describe_api(function: str | None = None) -> dict[str, Any]:
    """
    查看当前安装版本的 cjpy 查询接口文档。

    文档直接从 :mod:`cjpy.api` 中公开函数的签名、类型注解和 docstring 动态
    生成，因此与当前安装的 cjpy 版本保持一致，不需要 token 或网络连接。
    不传 ``function`` 时返回可查询接口目录；传入函数名时返回该函数的完整
    结构化说明。

    Args:
        function: 可选的 cjpy Python 函数名，例如 ``"get_market_data"``。
            也接受带 ``"cjpy."`` 前缀的名称。不传或传入空白字符串时返回
            接口目录。

    Returns:
        结构化接口文档字典。目录结果包含 ``functions``；单函数结果包含
        ``signature``、``parameters``、``returns``、``raises``、``examples``
        和完整 ``docstring`` 等字段。

    Raises:
        TypeError: ``function`` 既不是字符串也不是 ``None``。
        ValueError: 找不到指定的公开函数。

    Examples:
        >>> import cjpy
        >>> catalog = cjpy.describe_api()
        >>> market = cjpy.describe_api("get_market_data")
        >>> market["name"]
        'get_market_data'
    """
    if function is not None and not isinstance(function, str):
        raise TypeError("function 必须是字符串或 None")

    functions = _api_functions()
    if function is None or not function.strip():
        entries = []
        for name, target in sorted(functions.items()):
            docstring = inspect.getdoc(target) or ""
            description, _ = _split_docstring(docstring)
            entries.append({
                "name": name,
                "summary": _summary(description),
                "signature": f"{name}{inspect.signature(target)}",
                "deprecated": ".. deprecated::" in docstring,
            })
        return {
            "cjpy_version": __version__,
            "count": len(entries),
            "functions": entries,
        }

    name = _resolve_function_name(function)
    target = functions.get(name)
    if target is None:
        raise ValueError(f"未知的 cjpy API 函数：{function}")

    docstring = inspect.getdoc(target) or ""
    description, sections = _split_docstring(docstring)
    signature = inspect.signature(target)
    raises = _parse_named_items(sections.get("Raises", ""))
    related = list(dict.fromkeys(
        related_name.rsplit(".", 1)[-1]
        for related_name in _RELATED_FUNCTION_PATTERN.findall(docstring)
        if related_name.rsplit(".", 1)[-1] != name
    ))

    return {
        "cjpy_version": __version__,
        "name": name,
        "summary": _summary(description),
        "signature": f"{name}{signature}",
        "description": description,
        "parameters": _parameter_docs(target, sections.get("Args", "")),
        "returns": {
            "annotation": _format_annotation(signature.return_annotation),
            "description": sections.get("Returns", ""),
        },
        "raises": [
            {"type": exception_type, "description": exception_description}
            for exception_type, exception_description in raises.items()
        ],
        "examples": sections.get("Examples", ""),
        "notes": sections.get("Notes", ""),
        "related": related,
        "deprecated": ".. deprecated::" in docstring,
        "docstring": docstring,
    }


__all__ = ["describe_api"]
