# --*-- coding:utf-8 --*--
# @Time : 2026/4/20 16:29
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : base.py
# @Software : PyCharm

import json
import os
from pathlib import Path
from typing import Any

import requests
import urllib3

BASE_URL = "https://opi.tinysoft.com.cn/Service/Session/Call"
DEFAULT_TIMEOUT = 30
DEFAULT_VERIFY = False
TOKEN_ENV_NAME = "cj_key"
CONFIG_DIR = Path.home() / ".cjpy"
CONFIG_FILE = CONFIG_DIR / "config.json"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class CjError(Exception):
    """cjpy基础异常。"""


class CjConfigError(CjError):
    """cjpy配置异常。"""


class CjRequestError(CjError):
    """cjpy请求失败异常。"""


_user_token = None
_default_client = None
JsonValue = dict[str, Any] | list[Any] | str | int | float | bool | None
CallParams = list[Any] | dict[str, Any]


def _save_token(token: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps({"token": token}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def get_saved_token() -> str | None:
    """
    读取本地持久化token。

    Returns:
        str | None: 已保存的token；不存在或读取失败时返回None。
    """
    if not CONFIG_FILE.exists():
        return None

    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None

    token = data.get("token")
    return token or None


def set_token(token: str, persist: bool = True) -> None:
    """
    设置 ``cjpy`` 默认 token。

    Args:
        token: 接口认证 token。
        persist: 是否将 token 同时保存到用户目录配置文件。默认保存。

    设置后，后续默认 ``post_call()`` 和业务函数会复用该 token。
    默认情况下 token 会持久化保存，因此通常只需要设置一次。

    Raises:
        CjConfigError: token 为空时抛出。

    Examples:
        >>> import cjpy
        >>> cjpy.set_token("your-token")
    """
    global _user_token, _default_client

    if not token:
        raise CjConfigError("token不能为空")

    _user_token = token
    _replace_default_client(None)

    if persist:
        _save_token(token)


def clear_token(persist: bool = True) -> None:
    """
    清除 ``cjpy`` 默认 token。

    Args:
        persist: 是否同时删除用户目录中保存的 token，默认删除。

    Examples:
        >>> import cjpy
        >>> cjpy.clear_token()
    """
    global _user_token, _default_client

    _user_token = None
    _replace_default_client(None)

    if persist and CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def get_token(token: str | None = None) -> str:
    """
    获取接口认证 token。

    Args:
        token: 显式传入的 token。传入时优先使用该值。

    Returns:
        str: 可用于接口访问的 token。

    Raises:
        CjConfigError: 未传入 token，且内存、环境变量、配置文件中都找不到可用 token。

    Notes:
        token 的查找优先级如下：

        1. 函数参数 ``token``
        2. 通过 :func:`set_token` 设置的进程内 token
        3. 环境变量 ``cj_key``
        4. 用户目录下 ``~/.cjpy/config.json`` 中保存的 token

        环境变量优先于持久化配置文件，便于在 CI、多账号等场景下临时覆盖，
        而不必修改或删除全局配置。
    """
    if token:
        return token

    if _user_token:
        return _user_token

    env_token = os.getenv(TOKEN_ENV_NAME)
    if env_token:
        return env_token

    saved_token = get_saved_token()
    if not saved_token:
        raise CjConfigError("未设置token，请先调用cjpy.set_token(...)或设置环境变量cj_key")

    return saved_token


class CjClient:
    """
    ``cjpy`` 底层 HTTP 客户端。

    负责认证、公共请求头、请求编码、超时、证书校验和响应解析。
    业务函数通常不需要直接实例化该对象；如果需要自定义 ``base_url``、
    ``timeout``、``verify`` 或使用多账号场景，可以显式创建客户端并传给
    ``api.py`` 中的业务接口。

    Args:
        token: 显式传入的 token。不传时按 :func:`get_token` 的优先级查找。
        base_url: 服务端基础 URL。
        timeout: 请求超时秒数。
        verify: HTTPS 证书校验配置。可为 ``True``、``False`` 或证书路径字符串。

    Examples:
        >>> from cjpy.base import CjClient
        >>> client = CjClient(token="your-token", timeout=10)
        >>> client.post_call("funds", [])
    """

    def __init__(
        self,
        token: str | None = None,
        base_url: str = BASE_URL,
        timeout: int | float = DEFAULT_TIMEOUT,
        verify: bool | str = DEFAULT_VERIFY,
    ) -> None:
        self.token = get_token(token)
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verify = verify

    def close(self) -> None:
        """
        兼容保留的关闭方法。

        普通查询请求不再持有长期存活的 ``requests.Session``，因此这里不需要
        释放查询连接资源。该方法保留是为了兼容既有调用代码。
        """
        return None

    def __enter__(self) -> "CjClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "JSON-Encode": "utf-8",
            "Connection": "close",
        }

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        session.verify = self.verify
        return session

    @staticmethod
    def _summarize_response_text(text: str, limit: int = 500) -> str:
        summary = text.strip()
        if not summary:
            return "<empty>"
        if len(summary) > limit:
            return summary[:limit] + "...(truncated)"
        return summary

    @staticmethod
    def _parse_json_text(text: str) -> JsonValue:
        """
        解析服务端返回的 JSON 文本。

        这里统一使用 Python 标准库的 ``json.loads``，避免
        ``requests.Response.json()`` 因运行环境是否安装 ``simplejson`` 而产生
        不一致的行为。Tinysoft 某些接口会返回包含 ``NaN``、``Infinity`` 或
        ``-Infinity`` 的非标准 JSON；标准库默认会将它们分别解析为
        ``float("nan")``、``float("inf")`` 和 ``float("-inf")``，从而保留原始
        数值语义。需要输出严格 JSON 的调用方（例如 MCP）应在序列化边界进行清洗。
        """
        return json.loads(text)

    def post_call(self, func_name: str, params: CallParams) -> JsonValue:
        """
        调用 Tinysoft ``Session/Call`` 接口。

        Args:
            func_name: 远端函数名。
            params: 远端函数参数。根据接口约定，可以是位置参数列表或命名参数字典。

        Returns:
            dict | list | str: JSON 响应解析结果；响应不是 JSON 时返回文本。

        Raises:
            CjRequestError: 网络请求异常或 HTTP 状态码异常时抛出。
        """
        url = f"{self.base_url}/{func_name}"
        payload = {"func_call_params": params}
        try:
            with self._create_session() as session:
                with session.post(
                    url,
                    headers=self._headers(),
                    data=json.dumps(payload, ensure_ascii=False).encode("gbk"),
                    verify=self.verify,
                    timeout=self.timeout,
                ) as response:
                    text = response.text

                    if not response.ok:
                        summary = self._summarize_response_text(text)
                        raise CjRequestError(
                            f"调用 Tinysoft 接口失败：func={func_name}，"
                            f"HTTP {response.status_code}，url={url}，response={summary}"
                        )

                    try:
                        return self._parse_json_text(text)
                    except ValueError:
                        return text
        except requests.RequestException as exc:
            raise CjRequestError(
                f"调用 Tinysoft 接口异常：func={func_name}，url={url}，"
                f"type={exc.__class__.__name__}，message={exc}"
            ) from exc


def _replace_default_client(client: CjClient | None = None) -> None:
    global _default_client

    old_client = _default_client
    _default_client = client

    if old_client is not None and old_client is not client:
        old_client.close()


def get_default_client() -> CjClient:
    """
    获取默认客户端。

    该函数会按需延迟创建全局默认 ``CjClient``，避免在模块导入阶段立即读取 token。

    Returns:
        CjClient: 默认客户端实例。
    """
    global _default_client

    if _default_client is None:
        _default_client = CjClient()

    return _default_client


def set_default_client(client: CjClient) -> None:
    """
    设置默认客户端。

    主要用于测试、多账号或需要自定义 ``base_url``、``timeout``、``verify`` 的场景。

    Args:
        client: 要设置为默认值的 ``CjClient`` 实例。
    """
    _replace_default_client(client)


def post_call(func_name: str, params: CallParams) -> JsonValue:
    """
    使用默认客户端调用 Tinysoft ``Session/Call`` 接口。

    Args:
        func_name: 远端函数名。
        params: 远端函数参数。根据接口约定，可以是位置参数列表或命名参数字典。

    Returns:
        dict | list | str: JSON 响应解析结果；响应不是 JSON 时返回文本。
    """
    return get_default_client().post_call(func_name, params)
