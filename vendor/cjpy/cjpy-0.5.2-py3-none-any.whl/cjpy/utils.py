# --*-- coding:utf-8 --*--
# @Time : 2026/4/20 16:41
# @Author : baofh@cjsc
# @Email : baofh@cjsc.com.cn
# @File : utils.py
# @Software : PyCharm

def tscode(code: str) -> str:
    """
    Wind证券代码转换为天软证券代码，如果输入的本身就是天软代码，则不会改变
    Args:
        code: Wind证券代码，str类型

    Returns:
        天软证券代码
    """
    parts = code.split(sep='.')[::-1]

    if parts[0] == 'HK':
        return '{0}{1:0>5}'.format(*parts)

    return ''.join(parts)


